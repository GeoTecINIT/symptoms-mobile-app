export * as pb from 'google-protobuf';
export * from "google-protobuf/google/protobuf/any_pb";
export * from "google-protobuf/google/protobuf/duration_pb";
export * from "google-protobuf/google/protobuf/empty_pb";
export * from "google-protobuf/google/protobuf/timestamp_pb";
//# sourceMappingURL=index.js.map