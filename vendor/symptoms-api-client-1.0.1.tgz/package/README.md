# Symptoms API Client (Web)

## Update instructions
Run `update.sh` script after each file update in the definitions' folder.

> **Note:** Update / add `index.ts` files when required as you add or remove `.proto` files

## Usage
1. Run `npm pack` to generate a `tgz` file.
2. Install the `tgz` file.
3. (optional) Install protobuf types with `npm i -D @types/google-protobuf`.
