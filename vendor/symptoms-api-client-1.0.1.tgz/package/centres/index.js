export * from "./centres_pb";
export * from "./centres_grpc_web_pb";
//# sourceMappingURL=index.js.map