import * as jspb from 'google-protobuf'



export class ListCentresRequest extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListCentresRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListCentresRequest): ListCentresRequest.AsObject;
  static serializeBinaryToWriter(message: ListCentresRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListCentresRequest;
  static deserializeBinaryFromReader(message: ListCentresRequest, reader: jspb.BinaryReader): ListCentresRequest;
}

export namespace ListCentresRequest {
  export type AsObject = {
  }
}

export class ListCentresResponse extends jspb.Message {
  getCentresList(): Array<Centre>;
  setCentresList(value: Array<Centre>): ListCentresResponse;
  clearCentresList(): ListCentresResponse;
  addCentres(value?: Centre, index?: number): Centre;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListCentresResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListCentresResponse): ListCentresResponse.AsObject;
  static serializeBinaryToWriter(message: ListCentresResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListCentresResponse;
  static deserializeBinaryFromReader(message: ListCentresResponse, reader: jspb.BinaryReader): ListCentresResponse;
}

export namespace ListCentresResponse {
  export type AsObject = {
    centresList: Array<Centre.AsObject>,
  }
}

export class Centre extends jspb.Message {
  getId(): string;
  setId(value: string): Centre;

  getName(): string;
  setName(value: string): Centre;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Centre.AsObject;
  static toObject(includeInstance: boolean, msg: Centre): Centre.AsObject;
  static serializeBinaryToWriter(message: Centre, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Centre;
  static deserializeBinaryFromReader(message: Centre, reader: jspb.BinaryReader): Centre;
}

export namespace Centre {
  export type AsObject = {
    id: string,
    name: string,
  }
}

export class CreateCentreRequest extends jspb.Message {
  getName(): string;
  setName(value: string): CreateCentreRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateCentreRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateCentreRequest): CreateCentreRequest.AsObject;
  static serializeBinaryToWriter(message: CreateCentreRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateCentreRequest;
  static deserializeBinaryFromReader(message: CreateCentreRequest, reader: jspb.BinaryReader): CreateCentreRequest;
}

export namespace CreateCentreRequest {
  export type AsObject = {
    name: string,
  }
}

export class CreateCentreResponse extends jspb.Message {
  getId(): string;
  setId(value: string): CreateCentreResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateCentreResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CreateCentreResponse): CreateCentreResponse.AsObject;
  static serializeBinaryToWriter(message: CreateCentreResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateCentreResponse;
  static deserializeBinaryFromReader(message: CreateCentreResponse, reader: jspb.BinaryReader): CreateCentreResponse;
}

export namespace CreateCentreResponse {
  export type AsObject = {
    id: string,
  }
}

export class GetCentreRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetCentreRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetCentreRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetCentreRequest): GetCentreRequest.AsObject;
  static serializeBinaryToWriter(message: GetCentreRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetCentreRequest;
  static deserializeBinaryFromReader(message: GetCentreRequest, reader: jspb.BinaryReader): GetCentreRequest;
}

export namespace GetCentreRequest {
  export type AsObject = {
    id: string,
  }
}

