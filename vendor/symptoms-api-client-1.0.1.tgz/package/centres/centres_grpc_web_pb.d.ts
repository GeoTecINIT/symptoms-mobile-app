import * as grpcWeb from 'grpc-web';

import * as centres_centres_pb from '../centres/centres_pb';


export class CentresClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: centres_centres_pb.ListCentresRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: centres_centres_pb.ListCentresResponse) => void
  ): grpcWeb.ClientReadableStream<centres_centres_pb.ListCentresResponse>;

  create(
    request: centres_centres_pb.CreateCentreRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: centres_centres_pb.CreateCentreResponse) => void
  ): grpcWeb.ClientReadableStream<centres_centres_pb.CreateCentreResponse>;

  get(
    request: centres_centres_pb.GetCentreRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: centres_centres_pb.Centre) => void
  ): grpcWeb.ClientReadableStream<centres_centres_pb.Centre>;

}

export class CentresPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: centres_centres_pb.ListCentresRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<centres_centres_pb.ListCentresResponse>;

  create(
    request: centres_centres_pb.CreateCentreRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<centres_centres_pb.CreateCentreResponse>;

  get(
    request: centres_centres_pb.GetCentreRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<centres_centres_pb.Centre>;

}

