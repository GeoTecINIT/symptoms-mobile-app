import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb';


export class ListConfigsRequest extends jspb.Message {
  getTherapistId(): string;
  setTherapistId(value: string): ListConfigsRequest;
  hasTherapistId(): boolean;
  clearTherapistId(): ListConfigsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListConfigsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListConfigsRequest): ListConfigsRequest.AsObject;
  static serializeBinaryToWriter(message: ListConfigsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListConfigsRequest;
  static deserializeBinaryFromReader(message: ListConfigsRequest, reader: jspb.BinaryReader): ListConfigsRequest;
}

export namespace ListConfigsRequest {
  export type AsObject = {
    therapistId?: string,
  }

  export enum TherapistIdCase { 
    _THERAPIST_ID_NOT_SET = 0,
    THERAPIST_ID = 2,
  }
}

export class ListConfigsResponse extends jspb.Message {
  getAppConfigsList(): Array<AppConfig>;
  setAppConfigsList(value: Array<AppConfig>): ListConfigsResponse;
  clearAppConfigsList(): ListConfigsResponse;
  addAppConfigs(value?: AppConfig, index?: number): AppConfig;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListConfigsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListConfigsResponse): ListConfigsResponse.AsObject;
  static serializeBinaryToWriter(message: ListConfigsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListConfigsResponse;
  static deserializeBinaryFromReader(message: ListConfigsResponse, reader: jspb.BinaryReader): ListConfigsResponse;
}

export namespace ListConfigsResponse {
  export type AsObject = {
    appConfigsList: Array<AppConfig.AsObject>,
  }
}

export class AppConfig extends jspb.Message {
  getId(): string;
  setId(value: string): AppConfig;

  getName(): string;
  setName(value: string): AppConfig;

  getAppId(): string;
  setAppId(value: string): AppConfig;

  getCreatorId(): string;
  setCreatorId(value: string): AppConfig;

  getAppWorkflowId(): string;
  setAppWorkflowId(value: string): AppConfig;

  getCreatedAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreatedAt(value?: google_protobuf_timestamp_pb.Timestamp): AppConfig;
  hasCreatedAt(): boolean;
  clearCreatedAt(): AppConfig;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AppConfig.AsObject;
  static toObject(includeInstance: boolean, msg: AppConfig): AppConfig.AsObject;
  static serializeBinaryToWriter(message: AppConfig, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AppConfig;
  static deserializeBinaryFromReader(message: AppConfig, reader: jspb.BinaryReader): AppConfig;
}

export namespace AppConfig {
  export type AsObject = {
    id: string,
    name: string,
    appId: string,
    creatorId: string,
    appWorkflowId: string,
    createdAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class CreateConfigRequest extends jspb.Message {
  getName(): string;
  setName(value: string): CreateConfigRequest;

  getAppWorkflowId(): string;
  setAppWorkflowId(value: string): CreateConfigRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateConfigRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateConfigRequest): CreateConfigRequest.AsObject;
  static serializeBinaryToWriter(message: CreateConfigRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateConfigRequest;
  static deserializeBinaryFromReader(message: CreateConfigRequest, reader: jspb.BinaryReader): CreateConfigRequest;
}

export namespace CreateConfigRequest {
  export type AsObject = {
    name: string,
    appWorkflowId: string,
  }
}

export class CreateConfigResponse extends jspb.Message {
  getId(): string;
  setId(value: string): CreateConfigResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateConfigResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CreateConfigResponse): CreateConfigResponse.AsObject;
  static serializeBinaryToWriter(message: CreateConfigResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateConfigResponse;
  static deserializeBinaryFromReader(message: CreateConfigResponse, reader: jspb.BinaryReader): CreateConfigResponse;
}

export namespace CreateConfigResponse {
  export type AsObject = {
    id: string,
  }
}

export class DuplicateConfigRequest extends jspb.Message {
  getSourceId(): string;
  setSourceId(value: string): DuplicateConfigRequest;

  getNewName(): string;
  setNewName(value: string): DuplicateConfigRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DuplicateConfigRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DuplicateConfigRequest): DuplicateConfigRequest.AsObject;
  static serializeBinaryToWriter(message: DuplicateConfigRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DuplicateConfigRequest;
  static deserializeBinaryFromReader(message: DuplicateConfigRequest, reader: jspb.BinaryReader): DuplicateConfigRequest;
}

export namespace DuplicateConfigRequest {
  export type AsObject = {
    sourceId: string,
    newName: string,
  }
}

export class UpdateConfigRequest extends jspb.Message {
  getId(): string;
  setId(value: string): UpdateConfigRequest;

  getName(): string;
  setName(value: string): UpdateConfigRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateConfigRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateConfigRequest): UpdateConfigRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateConfigRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateConfigRequest;
  static deserializeBinaryFromReader(message: UpdateConfigRequest, reader: jspb.BinaryReader): UpdateConfigRequest;
}

export namespace UpdateConfigRequest {
  export type AsObject = {
    id: string,
    name: string,
  }
}

export class UpdateConfigResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateConfigResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateConfigResponse): UpdateConfigResponse.AsObject;
  static serializeBinaryToWriter(message: UpdateConfigResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateConfigResponse;
  static deserializeBinaryFromReader(message: UpdateConfigResponse, reader: jspb.BinaryReader): UpdateConfigResponse;
}

export namespace UpdateConfigResponse {
  export type AsObject = {
  }
}

export class GetConfigRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetConfigRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetConfigRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetConfigRequest): GetConfigRequest.AsObject;
  static serializeBinaryToWriter(message: GetConfigRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetConfigRequest;
  static deserializeBinaryFromReader(message: GetConfigRequest, reader: jspb.BinaryReader): GetConfigRequest;
}

export namespace GetConfigRequest {
  export type AsObject = {
    id: string,
  }
}

export class ListStudyConfigsRequest extends jspb.Message {
  getStudyId(): string;
  setStudyId(value: string): ListStudyConfigsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListStudyConfigsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListStudyConfigsRequest): ListStudyConfigsRequest.AsObject;
  static serializeBinaryToWriter(message: ListStudyConfigsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListStudyConfigsRequest;
  static deserializeBinaryFromReader(message: ListStudyConfigsRequest, reader: jspb.BinaryReader): ListStudyConfigsRequest;
}

export namespace ListStudyConfigsRequest {
  export type AsObject = {
    studyId: string,
  }
}

export class ListStudyConfigsResponse extends jspb.Message {
  getStudyConfigsList(): Array<StudyConfig>;
  setStudyConfigsList(value: Array<StudyConfig>): ListStudyConfigsResponse;
  clearStudyConfigsList(): ListStudyConfigsResponse;
  addStudyConfigs(value?: StudyConfig, index?: number): StudyConfig;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListStudyConfigsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListStudyConfigsResponse): ListStudyConfigsResponse.AsObject;
  static serializeBinaryToWriter(message: ListStudyConfigsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListStudyConfigsResponse;
  static deserializeBinaryFromReader(message: ListStudyConfigsResponse, reader: jspb.BinaryReader): ListStudyConfigsResponse;
}

export namespace ListStudyConfigsResponse {
  export type AsObject = {
    studyConfigsList: Array<StudyConfig.AsObject>,
  }
}

export class StudyConfig extends jspb.Message {
  getStudyId(): string;
  setStudyId(value: string): StudyConfig;

  getAppConfig(): AppConfig | undefined;
  setAppConfig(value?: AppConfig): StudyConfig;
  hasAppConfig(): boolean;
  clearAppConfig(): StudyConfig;

  getAddedAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setAddedAt(value?: google_protobuf_timestamp_pb.Timestamp): StudyConfig;
  hasAddedAt(): boolean;
  clearAddedAt(): StudyConfig;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StudyConfig.AsObject;
  static toObject(includeInstance: boolean, msg: StudyConfig): StudyConfig.AsObject;
  static serializeBinaryToWriter(message: StudyConfig, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StudyConfig;
  static deserializeBinaryFromReader(message: StudyConfig, reader: jspb.BinaryReader): StudyConfig;
}

export namespace StudyConfig {
  export type AsObject = {
    studyId: string,
    appConfig?: AppConfig.AsObject,
    addedAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class AddStudyConfigRequest extends jspb.Message {
  getId(): string;
  setId(value: string): AddStudyConfigRequest;

  getStudyId(): string;
  setStudyId(value: string): AddStudyConfigRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AddStudyConfigRequest.AsObject;
  static toObject(includeInstance: boolean, msg: AddStudyConfigRequest): AddStudyConfigRequest.AsObject;
  static serializeBinaryToWriter(message: AddStudyConfigRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AddStudyConfigRequest;
  static deserializeBinaryFromReader(message: AddStudyConfigRequest, reader: jspb.BinaryReader): AddStudyConfigRequest;
}

export namespace AddStudyConfigRequest {
  export type AsObject = {
    id: string,
    studyId: string,
  }
}

export class AddStudyConfigResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AddStudyConfigResponse.AsObject;
  static toObject(includeInstance: boolean, msg: AddStudyConfigResponse): AddStudyConfigResponse.AsObject;
  static serializeBinaryToWriter(message: AddStudyConfigResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AddStudyConfigResponse;
  static deserializeBinaryFromReader(message: AddStudyConfigResponse, reader: jspb.BinaryReader): AddStudyConfigResponse;
}

export namespace AddStudyConfigResponse {
  export type AsObject = {
  }
}

export class RemoveStudyConfigRequest extends jspb.Message {
  getId(): string;
  setId(value: string): RemoveStudyConfigRequest;

  getStudyId(): string;
  setStudyId(value: string): RemoveStudyConfigRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RemoveStudyConfigRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RemoveStudyConfigRequest): RemoveStudyConfigRequest.AsObject;
  static serializeBinaryToWriter(message: RemoveStudyConfigRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RemoveStudyConfigRequest;
  static deserializeBinaryFromReader(message: RemoveStudyConfigRequest, reader: jspb.BinaryReader): RemoveStudyConfigRequest;
}

export namespace RemoveStudyConfigRequest {
  export type AsObject = {
    id: string,
    studyId: string,
  }
}

export class RemoveStudyConfigResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RemoveStudyConfigResponse.AsObject;
  static toObject(includeInstance: boolean, msg: RemoveStudyConfigResponse): RemoveStudyConfigResponse.AsObject;
  static serializeBinaryToWriter(message: RemoveStudyConfigResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RemoveStudyConfigResponse;
  static deserializeBinaryFromReader(message: RemoveStudyConfigResponse, reader: jspb.BinaryReader): RemoveStudyConfigResponse;
}

export namespace RemoveStudyConfigResponse {
  export type AsObject = {
  }
}

export class GetLastStudyConfigRequest extends jspb.Message {
  getStudyId(): string;
  setStudyId(value: string): GetLastStudyConfigRequest;

  getAppId(): string;
  setAppId(value: string): GetLastStudyConfigRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetLastStudyConfigRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetLastStudyConfigRequest): GetLastStudyConfigRequest.AsObject;
  static serializeBinaryToWriter(message: GetLastStudyConfigRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetLastStudyConfigRequest;
  static deserializeBinaryFromReader(message: GetLastStudyConfigRequest, reader: jspb.BinaryReader): GetLastStudyConfigRequest;
}

export namespace GetLastStudyConfigRequest {
  export type AsObject = {
    studyId: string,
    appId: string,
  }
}

