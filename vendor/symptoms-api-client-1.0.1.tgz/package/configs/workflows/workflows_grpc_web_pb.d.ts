import * as grpcWeb from 'grpc-web';

import * as configs_workflows_workflows_pb from '../../configs/workflows/workflows_pb';


export class AppWorkflowsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_workflows_workflows_pb.ListAppWorkflowsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_workflows_workflows_pb.ListAppWorkflowsResponse) => void
  ): grpcWeb.ClientReadableStream<configs_workflows_workflows_pb.ListAppWorkflowsResponse>;

  create(
    request: configs_workflows_workflows_pb.CreateAppWorkflowRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_workflows_workflows_pb.CreateAppWorkflowResponse) => void
  ): grpcWeb.ClientReadableStream<configs_workflows_workflows_pb.CreateAppWorkflowResponse>;

  update(
    request: configs_workflows_workflows_pb.UpdateAppWorkflowRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_workflows_workflows_pb.UpdateAppWorkflowResponse) => void
  ): grpcWeb.ClientReadableStream<configs_workflows_workflows_pb.UpdateAppWorkflowResponse>;

  get(
    request: configs_workflows_workflows_pb.GetAppWorkflowRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_workflows_workflows_pb.AppWorkflow) => void
  ): grpcWeb.ClientReadableStream<configs_workflows_workflows_pb.AppWorkflow>;

  getPlaceholders(
    request: configs_workflows_workflows_pb.GetPlaceholdersRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_workflows_workflows_pb.GetPlaceholdersResponse) => void
  ): grpcWeb.ClientReadableStream<configs_workflows_workflows_pb.GetPlaceholdersResponse>;

  duplicate(
    request: configs_workflows_workflows_pb.DuplicateAppWorkflowRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_workflows_workflows_pb.CreateAppWorkflowResponse) => void
  ): grpcWeb.ClientReadableStream<configs_workflows_workflows_pb.CreateAppWorkflowResponse>;

}

export class AppWorkflowsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_workflows_workflows_pb.ListAppWorkflowsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_workflows_workflows_pb.ListAppWorkflowsResponse>;

  create(
    request: configs_workflows_workflows_pb.CreateAppWorkflowRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_workflows_workflows_pb.CreateAppWorkflowResponse>;

  update(
    request: configs_workflows_workflows_pb.UpdateAppWorkflowRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_workflows_workflows_pb.UpdateAppWorkflowResponse>;

  get(
    request: configs_workflows_workflows_pb.GetAppWorkflowRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_workflows_workflows_pb.AppWorkflow>;

  getPlaceholders(
    request: configs_workflows_workflows_pb.GetPlaceholdersRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_workflows_workflows_pb.GetPlaceholdersResponse>;

  duplicate(
    request: configs_workflows_workflows_pb.DuplicateAppWorkflowRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_workflows_workflows_pb.CreateAppWorkflowResponse>;

}

