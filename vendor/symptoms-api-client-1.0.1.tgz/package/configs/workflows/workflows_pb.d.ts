import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb';


export class ListAppWorkflowsRequest extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListAppWorkflowsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListAppWorkflowsRequest): ListAppWorkflowsRequest.AsObject;
  static serializeBinaryToWriter(message: ListAppWorkflowsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListAppWorkflowsRequest;
  static deserializeBinaryFromReader(message: ListAppWorkflowsRequest, reader: jspb.BinaryReader): ListAppWorkflowsRequest;
}

export namespace ListAppWorkflowsRequest {
  export type AsObject = {
  }
}

export class ListAppWorkflowsResponse extends jspb.Message {
  getWorkflowsList(): Array<AppWorkflow>;
  setWorkflowsList(value: Array<AppWorkflow>): ListAppWorkflowsResponse;
  clearWorkflowsList(): ListAppWorkflowsResponse;
  addWorkflows(value?: AppWorkflow, index?: number): AppWorkflow;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListAppWorkflowsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListAppWorkflowsResponse): ListAppWorkflowsResponse.AsObject;
  static serializeBinaryToWriter(message: ListAppWorkflowsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListAppWorkflowsResponse;
  static deserializeBinaryFromReader(message: ListAppWorkflowsResponse, reader: jspb.BinaryReader): ListAppWorkflowsResponse;
}

export namespace ListAppWorkflowsResponse {
  export type AsObject = {
    workflowsList: Array<AppWorkflow.AsObject>,
  }
}

export class AppWorkflow extends jspb.Message {
  getId(): string;
  setId(value: string): AppWorkflow;

  getCentreId(): string;
  setCentreId(value: string): AppWorkflow;

  getTitle(): string;
  setTitle(value: string): AppWorkflow;

  getAppId(): string;
  setAppId(value: string): AppWorkflow;

  getDescriptor(): string;
  setDescriptor(value: string): AppWorkflow;

  getCreatedAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreatedAt(value?: google_protobuf_timestamp_pb.Timestamp): AppWorkflow;
  hasCreatedAt(): boolean;
  clearCreatedAt(): AppWorkflow;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AppWorkflow.AsObject;
  static toObject(includeInstance: boolean, msg: AppWorkflow): AppWorkflow.AsObject;
  static serializeBinaryToWriter(message: AppWorkflow, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AppWorkflow;
  static deserializeBinaryFromReader(message: AppWorkflow, reader: jspb.BinaryReader): AppWorkflow;
}

export namespace AppWorkflow {
  export type AsObject = {
    id: string,
    centreId: string,
    title: string,
    appId: string,
    descriptor: string,
    createdAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class CreateAppWorkflowRequest extends jspb.Message {
  getTitle(): string;
  setTitle(value: string): CreateAppWorkflowRequest;

  getAppId(): string;
  setAppId(value: string): CreateAppWorkflowRequest;

  getDescriptor(): string;
  setDescriptor(value: string): CreateAppWorkflowRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateAppWorkflowRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateAppWorkflowRequest): CreateAppWorkflowRequest.AsObject;
  static serializeBinaryToWriter(message: CreateAppWorkflowRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateAppWorkflowRequest;
  static deserializeBinaryFromReader(message: CreateAppWorkflowRequest, reader: jspb.BinaryReader): CreateAppWorkflowRequest;
}

export namespace CreateAppWorkflowRequest {
  export type AsObject = {
    title: string,
    appId: string,
    descriptor: string,
  }
}

export class CreateAppWorkflowResponse extends jspb.Message {
  getId(): string;
  setId(value: string): CreateAppWorkflowResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateAppWorkflowResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CreateAppWorkflowResponse): CreateAppWorkflowResponse.AsObject;
  static serializeBinaryToWriter(message: CreateAppWorkflowResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateAppWorkflowResponse;
  static deserializeBinaryFromReader(message: CreateAppWorkflowResponse, reader: jspb.BinaryReader): CreateAppWorkflowResponse;
}

export namespace CreateAppWorkflowResponse {
  export type AsObject = {
    id: string,
  }
}

export class UpdateAppWorkflowRequest extends jspb.Message {
  getId(): string;
  setId(value: string): UpdateAppWorkflowRequest;

  getDescriptor(): string;
  setDescriptor(value: string): UpdateAppWorkflowRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateAppWorkflowRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateAppWorkflowRequest): UpdateAppWorkflowRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateAppWorkflowRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateAppWorkflowRequest;
  static deserializeBinaryFromReader(message: UpdateAppWorkflowRequest, reader: jspb.BinaryReader): UpdateAppWorkflowRequest;
}

export namespace UpdateAppWorkflowRequest {
  export type AsObject = {
    id: string,
    descriptor: string,
  }
}

export class UpdateAppWorkflowResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateAppWorkflowResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateAppWorkflowResponse): UpdateAppWorkflowResponse.AsObject;
  static serializeBinaryToWriter(message: UpdateAppWorkflowResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateAppWorkflowResponse;
  static deserializeBinaryFromReader(message: UpdateAppWorkflowResponse, reader: jspb.BinaryReader): UpdateAppWorkflowResponse;
}

export namespace UpdateAppWorkflowResponse {
  export type AsObject = {
  }
}

export class GetAppWorkflowRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetAppWorkflowRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetAppWorkflowRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetAppWorkflowRequest): GetAppWorkflowRequest.AsObject;
  static serializeBinaryToWriter(message: GetAppWorkflowRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetAppWorkflowRequest;
  static deserializeBinaryFromReader(message: GetAppWorkflowRequest, reader: jspb.BinaryReader): GetAppWorkflowRequest;
}

export namespace GetAppWorkflowRequest {
  export type AsObject = {
    id: string,
  }
}

export class GetPlaceholdersRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetPlaceholdersRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetPlaceholdersRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetPlaceholdersRequest): GetPlaceholdersRequest.AsObject;
  static serializeBinaryToWriter(message: GetPlaceholdersRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetPlaceholdersRequest;
  static deserializeBinaryFromReader(message: GetPlaceholdersRequest, reader: jspb.BinaryReader): GetPlaceholdersRequest;
}

export namespace GetPlaceholdersRequest {
  export type AsObject = {
    id: string,
  }
}

export class GetPlaceholdersResponse extends jspb.Message {
  getPlaceholdersList(): Array<Placeholder>;
  setPlaceholdersList(value: Array<Placeholder>): GetPlaceholdersResponse;
  clearPlaceholdersList(): GetPlaceholdersResponse;
  addPlaceholders(value?: Placeholder, index?: number): Placeholder;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetPlaceholdersResponse.AsObject;
  static toObject(includeInstance: boolean, msg: GetPlaceholdersResponse): GetPlaceholdersResponse.AsObject;
  static serializeBinaryToWriter(message: GetPlaceholdersResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetPlaceholdersResponse;
  static deserializeBinaryFromReader(message: GetPlaceholdersResponse, reader: jspb.BinaryReader): GetPlaceholdersResponse;
}

export namespace GetPlaceholdersResponse {
  export type AsObject = {
    placeholdersList: Array<Placeholder.AsObject>,
  }
}

export class Placeholder extends jspb.Message {
  getCode(): string;
  setCode(value: string): Placeholder;

  getDescription(): string;
  setDescription(value: string): Placeholder;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Placeholder.AsObject;
  static toObject(includeInstance: boolean, msg: Placeholder): Placeholder.AsObject;
  static serializeBinaryToWriter(message: Placeholder, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Placeholder;
  static deserializeBinaryFromReader(message: Placeholder, reader: jspb.BinaryReader): Placeholder;
}

export namespace Placeholder {
  export type AsObject = {
    code: string,
    description: string,
  }
}

export class DuplicateAppWorkflowRequest extends jspb.Message {
  getSourceId(): string;
  setSourceId(value: string): DuplicateAppWorkflowRequest;

  getNewTitle(): string;
  setNewTitle(value: string): DuplicateAppWorkflowRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DuplicateAppWorkflowRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DuplicateAppWorkflowRequest): DuplicateAppWorkflowRequest.AsObject;
  static serializeBinaryToWriter(message: DuplicateAppWorkflowRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DuplicateAppWorkflowRequest;
  static deserializeBinaryFromReader(message: DuplicateAppWorkflowRequest, reader: jspb.BinaryReader): DuplicateAppWorkflowRequest;
}

export namespace DuplicateAppWorkflowRequest {
  export type AsObject = {
    sourceId: string,
    newTitle: string,
  }
}

