import * as jspb from 'google-protobuf'



export class ListNotificationsRequest extends jspb.Message {
  getConfigId(): string;
  setConfigId(value: string): ListNotificationsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListNotificationsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListNotificationsRequest): ListNotificationsRequest.AsObject;
  static serializeBinaryToWriter(message: ListNotificationsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListNotificationsRequest;
  static deserializeBinaryFromReader(message: ListNotificationsRequest, reader: jspb.BinaryReader): ListNotificationsRequest;
}

export namespace ListNotificationsRequest {
  export type AsObject = {
    configId: string,
  }
}

export class ListNotificationsResponse extends jspb.Message {
  getNotificationsList(): Array<Notification>;
  setNotificationsList(value: Array<Notification>): ListNotificationsResponse;
  clearNotificationsList(): ListNotificationsResponse;
  addNotifications(value?: Notification, index?: number): Notification;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListNotificationsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListNotificationsResponse): ListNotificationsResponse.AsObject;
  static serializeBinaryToWriter(message: ListNotificationsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListNotificationsResponse;
  static deserializeBinaryFromReader(message: ListNotificationsResponse, reader: jspb.BinaryReader): ListNotificationsResponse;
}

export namespace ListNotificationsResponse {
  export type AsObject = {
    notificationsList: Array<Notification.AsObject>,
  }
}

export class Notification extends jspb.Message {
  getId(): string;
  setId(value: string): Notification;

  getConfigId(): string;
  setConfigId(value: string): Notification;

  getTitle(): string;
  setTitle(value: string): Notification;

  getBody(): string;
  setBody(value: string): Notification;

  getPlaceholderCode(): string;
  setPlaceholderCode(value: string): Notification;

  getDeprecated(): boolean;
  setDeprecated(value: boolean): Notification;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Notification.AsObject;
  static toObject(includeInstance: boolean, msg: Notification): Notification.AsObject;
  static serializeBinaryToWriter(message: Notification, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Notification;
  static deserializeBinaryFromReader(message: Notification, reader: jspb.BinaryReader): Notification;
}

export namespace Notification {
  export type AsObject = {
    id: string,
    configId: string,
    title: string,
    body: string,
    placeholderCode: string,
    deprecated: boolean,
  }
}

export class AddNotificationRequest extends jspb.Message {
  getConfigId(): string;
  setConfigId(value: string): AddNotificationRequest;

  getTitle(): string;
  setTitle(value: string): AddNotificationRequest;

  getBody(): string;
  setBody(value: string): AddNotificationRequest;

  getPlaceholderCode(): string;
  setPlaceholderCode(value: string): AddNotificationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AddNotificationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: AddNotificationRequest): AddNotificationRequest.AsObject;
  static serializeBinaryToWriter(message: AddNotificationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AddNotificationRequest;
  static deserializeBinaryFromReader(message: AddNotificationRequest, reader: jspb.BinaryReader): AddNotificationRequest;
}

export namespace AddNotificationRequest {
  export type AsObject = {
    configId: string,
    title: string,
    body: string,
    placeholderCode: string,
  }
}

export class AddNotificationResponse extends jspb.Message {
  getId(): string;
  setId(value: string): AddNotificationResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AddNotificationResponse.AsObject;
  static toObject(includeInstance: boolean, msg: AddNotificationResponse): AddNotificationResponse.AsObject;
  static serializeBinaryToWriter(message: AddNotificationResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AddNotificationResponse;
  static deserializeBinaryFromReader(message: AddNotificationResponse, reader: jspb.BinaryReader): AddNotificationResponse;
}

export namespace AddNotificationResponse {
  export type AsObject = {
    id: string,
  }
}

export class UpdateNotificationRequest extends jspb.Message {
  getId(): string;
  setId(value: string): UpdateNotificationRequest;

  getTitle(): string;
  setTitle(value: string): UpdateNotificationRequest;

  getBody(): string;
  setBody(value: string): UpdateNotificationRequest;

  getPlaceholderCode(): string;
  setPlaceholderCode(value: string): UpdateNotificationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateNotificationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateNotificationRequest): UpdateNotificationRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateNotificationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateNotificationRequest;
  static deserializeBinaryFromReader(message: UpdateNotificationRequest, reader: jspb.BinaryReader): UpdateNotificationRequest;
}

export namespace UpdateNotificationRequest {
  export type AsObject = {
    id: string,
    title: string,
    body: string,
    placeholderCode: string,
  }
}

export class UpdateNotificationResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateNotificationResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateNotificationResponse): UpdateNotificationResponse.AsObject;
  static serializeBinaryToWriter(message: UpdateNotificationResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateNotificationResponse;
  static deserializeBinaryFromReader(message: UpdateNotificationResponse, reader: jspb.BinaryReader): UpdateNotificationResponse;
}

export namespace UpdateNotificationResponse {
  export type AsObject = {
  }
}

export class RemoveNotificationRequest extends jspb.Message {
  getId(): string;
  setId(value: string): RemoveNotificationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RemoveNotificationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RemoveNotificationRequest): RemoveNotificationRequest.AsObject;
  static serializeBinaryToWriter(message: RemoveNotificationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RemoveNotificationRequest;
  static deserializeBinaryFromReader(message: RemoveNotificationRequest, reader: jspb.BinaryReader): RemoveNotificationRequest;
}

export namespace RemoveNotificationRequest {
  export type AsObject = {
    id: string,
  }
}

export class RemoveNotificationResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RemoveNotificationResponse.AsObject;
  static toObject(includeInstance: boolean, msg: RemoveNotificationResponse): RemoveNotificationResponse.AsObject;
  static serializeBinaryToWriter(message: RemoveNotificationResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RemoveNotificationResponse;
  static deserializeBinaryFromReader(message: RemoveNotificationResponse, reader: jspb.BinaryReader): RemoveNotificationResponse;
}

export namespace RemoveNotificationResponse {
  export type AsObject = {
  }
}

export class GetNotificationRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetNotificationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetNotificationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetNotificationRequest): GetNotificationRequest.AsObject;
  static serializeBinaryToWriter(message: GetNotificationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetNotificationRequest;
  static deserializeBinaryFromReader(message: GetNotificationRequest, reader: jspb.BinaryReader): GetNotificationRequest;
}

export namespace GetNotificationRequest {
  export type AsObject = {
    id: string,
  }
}

export class CopyAllNotificationsRequest extends jspb.Message {
  getSourceConfigId(): string;
  setSourceConfigId(value: string): CopyAllNotificationsRequest;

  getTargetConfigId(): string;
  setTargetConfigId(value: string): CopyAllNotificationsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CopyAllNotificationsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CopyAllNotificationsRequest): CopyAllNotificationsRequest.AsObject;
  static serializeBinaryToWriter(message: CopyAllNotificationsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CopyAllNotificationsRequest;
  static deserializeBinaryFromReader(message: CopyAllNotificationsRequest, reader: jspb.BinaryReader): CopyAllNotificationsRequest;
}

export namespace CopyAllNotificationsRequest {
  export type AsObject = {
    sourceConfigId: string,
    targetConfigId: string,
  }
}

export class CopyAllNotificationsResponse extends jspb.Message {
  getOriginalIdsList(): Array<string>;
  setOriginalIdsList(value: Array<string>): CopyAllNotificationsResponse;
  clearOriginalIdsList(): CopyAllNotificationsResponse;
  addOriginalIds(value: string, index?: number): CopyAllNotificationsResponse;

  getNewIdsList(): Array<string>;
  setNewIdsList(value: Array<string>): CopyAllNotificationsResponse;
  clearNewIdsList(): CopyAllNotificationsResponse;
  addNewIds(value: string, index?: number): CopyAllNotificationsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CopyAllNotificationsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CopyAllNotificationsResponse): CopyAllNotificationsResponse.AsObject;
  static serializeBinaryToWriter(message: CopyAllNotificationsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CopyAllNotificationsResponse;
  static deserializeBinaryFromReader(message: CopyAllNotificationsResponse, reader: jspb.BinaryReader): CopyAllNotificationsResponse;
}

export namespace CopyAllNotificationsResponse {
  export type AsObject = {
    originalIdsList: Array<string>,
    newIdsList: Array<string>,
  }
}

