import * as grpcWeb from 'grpc-web';

import * as configs_notifications_notifications_pb from '../../configs/notifications/notifications_pb';


export class ConfigNotificationsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_notifications_notifications_pb.ListNotificationsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_notifications_notifications_pb.ListNotificationsResponse) => void
  ): grpcWeb.ClientReadableStream<configs_notifications_notifications_pb.ListNotificationsResponse>;

  add(
    request: configs_notifications_notifications_pb.AddNotificationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_notifications_notifications_pb.AddNotificationResponse) => void
  ): grpcWeb.ClientReadableStream<configs_notifications_notifications_pb.AddNotificationResponse>;

  update(
    request: configs_notifications_notifications_pb.UpdateNotificationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_notifications_notifications_pb.UpdateNotificationResponse) => void
  ): grpcWeb.ClientReadableStream<configs_notifications_notifications_pb.UpdateNotificationResponse>;

  remove(
    request: configs_notifications_notifications_pb.RemoveNotificationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_notifications_notifications_pb.RemoveNotificationResponse) => void
  ): grpcWeb.ClientReadableStream<configs_notifications_notifications_pb.RemoveNotificationResponse>;

  get(
    request: configs_notifications_notifications_pb.GetNotificationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_notifications_notifications_pb.Notification) => void
  ): grpcWeb.ClientReadableStream<configs_notifications_notifications_pb.Notification>;

  copyAll(
    request: configs_notifications_notifications_pb.CopyAllNotificationsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_notifications_notifications_pb.CopyAllNotificationsResponse) => void
  ): grpcWeb.ClientReadableStream<configs_notifications_notifications_pb.CopyAllNotificationsResponse>;

}

export class ConfigNotificationsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_notifications_notifications_pb.ListNotificationsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_notifications_notifications_pb.ListNotificationsResponse>;

  add(
    request: configs_notifications_notifications_pb.AddNotificationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_notifications_notifications_pb.AddNotificationResponse>;

  update(
    request: configs_notifications_notifications_pb.UpdateNotificationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_notifications_notifications_pb.UpdateNotificationResponse>;

  remove(
    request: configs_notifications_notifications_pb.RemoveNotificationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_notifications_notifications_pb.RemoveNotificationResponse>;

  get(
    request: configs_notifications_notifications_pb.GetNotificationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_notifications_notifications_pb.Notification>;

  copyAll(
    request: configs_notifications_notifications_pb.CopyAllNotificationsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_notifications_notifications_pb.CopyAllNotificationsResponse>;

}

