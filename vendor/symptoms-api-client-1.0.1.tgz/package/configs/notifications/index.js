export * from "./notifications_pb";
export * from "./notifications_grpc_web_pb";
//# sourceMappingURL=index.js.map