import * as grpcWeb from 'grpc-web';

import * as configs_configs_pb from '../configs/configs_pb';


export class AppConfigurationsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_configs_pb.ListConfigsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_configs_pb.ListConfigsResponse) => void
  ): grpcWeb.ClientReadableStream<configs_configs_pb.ListConfigsResponse>;

  create(
    request: configs_configs_pb.CreateConfigRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_configs_pb.CreateConfigResponse) => void
  ): grpcWeb.ClientReadableStream<configs_configs_pb.CreateConfigResponse>;

  duplicate(
    request: configs_configs_pb.DuplicateConfigRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_configs_pb.CreateConfigResponse) => void
  ): grpcWeb.ClientReadableStream<configs_configs_pb.CreateConfigResponse>;

  update(
    request: configs_configs_pb.UpdateConfigRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_configs_pb.UpdateConfigResponse) => void
  ): grpcWeb.ClientReadableStream<configs_configs_pb.UpdateConfigResponse>;

  get(
    request: configs_configs_pb.GetConfigRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_configs_pb.AppConfig) => void
  ): grpcWeb.ClientReadableStream<configs_configs_pb.AppConfig>;

}

export class StudyConfigurationsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_configs_pb.ListStudyConfigsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_configs_pb.ListStudyConfigsResponse) => void
  ): grpcWeb.ClientReadableStream<configs_configs_pb.ListStudyConfigsResponse>;

  add(
    request: configs_configs_pb.AddStudyConfigRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_configs_pb.AddStudyConfigResponse) => void
  ): grpcWeb.ClientReadableStream<configs_configs_pb.AddStudyConfigResponse>;

  remove(
    request: configs_configs_pb.RemoveStudyConfigRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_configs_pb.RemoveStudyConfigResponse) => void
  ): grpcWeb.ClientReadableStream<configs_configs_pb.RemoveStudyConfigResponse>;

  getLast(
    request: configs_configs_pb.GetLastStudyConfigRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_configs_pb.AppConfig) => void
  ): grpcWeb.ClientReadableStream<configs_configs_pb.AppConfig>;

}

export class AppConfigurationsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_configs_pb.ListConfigsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_configs_pb.ListConfigsResponse>;

  create(
    request: configs_configs_pb.CreateConfigRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_configs_pb.CreateConfigResponse>;

  duplicate(
    request: configs_configs_pb.DuplicateConfigRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_configs_pb.CreateConfigResponse>;

  update(
    request: configs_configs_pb.UpdateConfigRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_configs_pb.UpdateConfigResponse>;

  get(
    request: configs_configs_pb.GetConfigRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_configs_pb.AppConfig>;

}

export class StudyConfigurationsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_configs_pb.ListStudyConfigsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_configs_pb.ListStudyConfigsResponse>;

  add(
    request: configs_configs_pb.AddStudyConfigRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_configs_pb.AddStudyConfigResponse>;

  remove(
    request: configs_configs_pb.RemoveStudyConfigRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_configs_pb.RemoveStudyConfigResponse>;

  getLast(
    request: configs_configs_pb.GetLastStudyConfigRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_configs_pb.AppConfig>;

}

