import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb';


export class ListContentsRequest extends jspb.Message {
  getTherapistId(): string;
  setTherapistId(value: string): ListContentsRequest;
  hasTherapistId(): boolean;
  clearTherapistId(): ListContentsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListContentsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListContentsRequest): ListContentsRequest.AsObject;
  static serializeBinaryToWriter(message: ListContentsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListContentsRequest;
  static deserializeBinaryFromReader(message: ListContentsRequest, reader: jspb.BinaryReader): ListContentsRequest;
}

export namespace ListContentsRequest {
  export type AsObject = {
    therapistId?: string,
  }

  export enum TherapistIdCase { 
    _THERAPIST_ID_NOT_SET = 0,
    THERAPIST_ID = 1,
  }
}

export class ListContentsResponse extends jspb.Message {
  getContentList(): Array<Content>;
  setContentList(value: Array<Content>): ListContentsResponse;
  clearContentList(): ListContentsResponse;
  addContent(value?: Content, index?: number): Content;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListContentsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListContentsResponse): ListContentsResponse.AsObject;
  static serializeBinaryToWriter(message: ListContentsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListContentsResponse;
  static deserializeBinaryFromReader(message: ListContentsResponse, reader: jspb.BinaryReader): ListContentsResponse;
}

export namespace ListContentsResponse {
  export type AsObject = {
    contentList: Array<Content.AsObject>,
  }
}

export class Content extends jspb.Message {
  getId(): string;
  setId(value: string): Content;

  getCreatorId(): string;
  setCreatorId(value: string): Content;

  getTitle(): string;
  setTitle(value: string): Content;

  getText(): string;
  setText(value: string): Content;

  getCreatedAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreatedAt(value?: google_protobuf_timestamp_pb.Timestamp): Content;
  hasCreatedAt(): boolean;
  clearCreatedAt(): Content;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Content.AsObject;
  static toObject(includeInstance: boolean, msg: Content): Content.AsObject;
  static serializeBinaryToWriter(message: Content, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Content;
  static deserializeBinaryFromReader(message: Content, reader: jspb.BinaryReader): Content;
}

export namespace Content {
  export type AsObject = {
    id: string,
    creatorId: string,
    title: string,
    text: string,
    createdAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class CreateContentRequest extends jspb.Message {
  getTitle(): string;
  setTitle(value: string): CreateContentRequest;

  getText(): string;
  setText(value: string): CreateContentRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateContentRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateContentRequest): CreateContentRequest.AsObject;
  static serializeBinaryToWriter(message: CreateContentRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateContentRequest;
  static deserializeBinaryFromReader(message: CreateContentRequest, reader: jspb.BinaryReader): CreateContentRequest;
}

export namespace CreateContentRequest {
  export type AsObject = {
    title: string,
    text: string,
  }
}

export class CreateContentResponse extends jspb.Message {
  getId(): string;
  setId(value: string): CreateContentResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateContentResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CreateContentResponse): CreateContentResponse.AsObject;
  static serializeBinaryToWriter(message: CreateContentResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateContentResponse;
  static deserializeBinaryFromReader(message: CreateContentResponse, reader: jspb.BinaryReader): CreateContentResponse;
}

export namespace CreateContentResponse {
  export type AsObject = {
    id: string,
  }
}

export class DuplicateContentRequest extends jspb.Message {
  getSourceId(): string;
  setSourceId(value: string): DuplicateContentRequest;

  getNewTitle(): string;
  setNewTitle(value: string): DuplicateContentRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DuplicateContentRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DuplicateContentRequest): DuplicateContentRequest.AsObject;
  static serializeBinaryToWriter(message: DuplicateContentRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DuplicateContentRequest;
  static deserializeBinaryFromReader(message: DuplicateContentRequest, reader: jspb.BinaryReader): DuplicateContentRequest;
}

export namespace DuplicateContentRequest {
  export type AsObject = {
    sourceId: string,
    newTitle: string,
  }
}

export class UpdateContentRequest extends jspb.Message {
  getId(): string;
  setId(value: string): UpdateContentRequest;

  getTitle(): string;
  setTitle(value: string): UpdateContentRequest;

  getText(): string;
  setText(value: string): UpdateContentRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateContentRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateContentRequest): UpdateContentRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateContentRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateContentRequest;
  static deserializeBinaryFromReader(message: UpdateContentRequest, reader: jspb.BinaryReader): UpdateContentRequest;
}

export namespace UpdateContentRequest {
  export type AsObject = {
    id: string,
    title: string,
    text: string,
  }
}

export class UpdateContentResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateContentResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateContentResponse): UpdateContentResponse.AsObject;
  static serializeBinaryToWriter(message: UpdateContentResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateContentResponse;
  static deserializeBinaryFromReader(message: UpdateContentResponse, reader: jspb.BinaryReader): UpdateContentResponse;
}

export namespace UpdateContentResponse {
  export type AsObject = {
  }
}

export class GetContentRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetContentRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetContentRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetContentRequest): GetContentRequest.AsObject;
  static serializeBinaryToWriter(message: GetContentRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetContentRequest;
  static deserializeBinaryFromReader(message: GetContentRequest, reader: jspb.BinaryReader): GetContentRequest;
}

export namespace GetContentRequest {
  export type AsObject = {
    id: string,
  }
}

export class ListConfigContentsRequest extends jspb.Message {
  getConfigId(): string;
  setConfigId(value: string): ListConfigContentsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListConfigContentsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListConfigContentsRequest): ListConfigContentsRequest.AsObject;
  static serializeBinaryToWriter(message: ListConfigContentsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListConfigContentsRequest;
  static deserializeBinaryFromReader(message: ListConfigContentsRequest, reader: jspb.BinaryReader): ListConfigContentsRequest;
}

export namespace ListConfigContentsRequest {
  export type AsObject = {
    configId: string,
  }
}

export class ListConfigContentsResponse extends jspb.Message {
  getContentsList(): Array<ConfigContent>;
  setContentsList(value: Array<ConfigContent>): ListConfigContentsResponse;
  clearContentsList(): ListConfigContentsResponse;
  addContents(value?: ConfigContent, index?: number): ConfigContent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListConfigContentsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListConfigContentsResponse): ListConfigContentsResponse.AsObject;
  static serializeBinaryToWriter(message: ListConfigContentsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListConfigContentsResponse;
  static deserializeBinaryFromReader(message: ListConfigContentsResponse, reader: jspb.BinaryReader): ListConfigContentsResponse;
}

export namespace ListConfigContentsResponse {
  export type AsObject = {
    contentsList: Array<ConfigContent.AsObject>,
  }
}

export class ConfigContent extends jspb.Message {
  getConfigId(): string;
  setConfigId(value: string): ConfigContent;

  getIndex(): number;
  setIndex(value: number): ConfigContent;

  getContent(): Content | undefined;
  setContent(value?: Content): ConfigContent;
  hasContent(): boolean;
  clearContent(): ConfigContent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ConfigContent.AsObject;
  static toObject(includeInstance: boolean, msg: ConfigContent): ConfigContent.AsObject;
  static serializeBinaryToWriter(message: ConfigContent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ConfigContent;
  static deserializeBinaryFromReader(message: ConfigContent, reader: jspb.BinaryReader): ConfigContent;
}

export namespace ConfigContent {
  export type AsObject = {
    configId: string,
    index: number,
    content?: Content.AsObject,
  }
}

export class AddConfigContentRequest extends jspb.Message {
  getConfigId(): string;
  setConfigId(value: string): AddConfigContentRequest;

  getContentId(): string;
  setContentId(value: string): AddConfigContentRequest;

  getIndex(): number;
  setIndex(value: number): AddConfigContentRequest;
  hasIndex(): boolean;
  clearIndex(): AddConfigContentRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AddConfigContentRequest.AsObject;
  static toObject(includeInstance: boolean, msg: AddConfigContentRequest): AddConfigContentRequest.AsObject;
  static serializeBinaryToWriter(message: AddConfigContentRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AddConfigContentRequest;
  static deserializeBinaryFromReader(message: AddConfigContentRequest, reader: jspb.BinaryReader): AddConfigContentRequest;
}

export namespace AddConfigContentRequest {
  export type AsObject = {
    configId: string,
    contentId: string,
    index?: number,
  }

  export enum IndexCase { 
    _INDEX_NOT_SET = 0,
    INDEX = 3,
  }
}

export class AddConfigContentResponse extends jspb.Message {
  getIndex(): number;
  setIndex(value: number): AddConfigContentResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AddConfigContentResponse.AsObject;
  static toObject(includeInstance: boolean, msg: AddConfigContentResponse): AddConfigContentResponse.AsObject;
  static serializeBinaryToWriter(message: AddConfigContentResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AddConfigContentResponse;
  static deserializeBinaryFromReader(message: AddConfigContentResponse, reader: jspb.BinaryReader): AddConfigContentResponse;
}

export namespace AddConfigContentResponse {
  export type AsObject = {
    index: number,
  }
}

export class MoveConfigContentRequest extends jspb.Message {
  getConfigId(): string;
  setConfigId(value: string): MoveConfigContentRequest;

  getContentId(): string;
  setContentId(value: string): MoveConfigContentRequest;

  getIndex(): number;
  setIndex(value: number): MoveConfigContentRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MoveConfigContentRequest.AsObject;
  static toObject(includeInstance: boolean, msg: MoveConfigContentRequest): MoveConfigContentRequest.AsObject;
  static serializeBinaryToWriter(message: MoveConfigContentRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MoveConfigContentRequest;
  static deserializeBinaryFromReader(message: MoveConfigContentRequest, reader: jspb.BinaryReader): MoveConfigContentRequest;
}

export namespace MoveConfigContentRequest {
  export type AsObject = {
    configId: string,
    contentId: string,
    index: number,
  }
}

export class MoveConfigContentResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MoveConfigContentResponse.AsObject;
  static toObject(includeInstance: boolean, msg: MoveConfigContentResponse): MoveConfigContentResponse.AsObject;
  static serializeBinaryToWriter(message: MoveConfigContentResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MoveConfigContentResponse;
  static deserializeBinaryFromReader(message: MoveConfigContentResponse, reader: jspb.BinaryReader): MoveConfigContentResponse;
}

export namespace MoveConfigContentResponse {
  export type AsObject = {
  }
}

export class RemoveConfigContentRequest extends jspb.Message {
  getConfigId(): string;
  setConfigId(value: string): RemoveConfigContentRequest;

  getContentId(): string;
  setContentId(value: string): RemoveConfigContentRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RemoveConfigContentRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RemoveConfigContentRequest): RemoveConfigContentRequest.AsObject;
  static serializeBinaryToWriter(message: RemoveConfigContentRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RemoveConfigContentRequest;
  static deserializeBinaryFromReader(message: RemoveConfigContentRequest, reader: jspb.BinaryReader): RemoveConfigContentRequest;
}

export namespace RemoveConfigContentRequest {
  export type AsObject = {
    configId: string,
    contentId: string,
  }
}

export class RemoveConfigContentResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RemoveConfigContentResponse.AsObject;
  static toObject(includeInstance: boolean, msg: RemoveConfigContentResponse): RemoveConfigContentResponse.AsObject;
  static serializeBinaryToWriter(message: RemoveConfigContentResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RemoveConfigContentResponse;
  static deserializeBinaryFromReader(message: RemoveConfigContentResponse, reader: jspb.BinaryReader): RemoveConfigContentResponse;
}

export namespace RemoveConfigContentResponse {
  export type AsObject = {
  }
}

export class ListConfigContentsNotificationsRequest extends jspb.Message {
  getConfigId(): string;
  setConfigId(value: string): ListConfigContentsNotificationsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListConfigContentsNotificationsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListConfigContentsNotificationsRequest): ListConfigContentsNotificationsRequest.AsObject;
  static serializeBinaryToWriter(message: ListConfigContentsNotificationsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListConfigContentsNotificationsRequest;
  static deserializeBinaryFromReader(message: ListConfigContentsNotificationsRequest, reader: jspb.BinaryReader): ListConfigContentsNotificationsRequest;
}

export namespace ListConfigContentsNotificationsRequest {
  export type AsObject = {
    configId: string,
  }
}

export class ListConfigContentsNotificationsResponse extends jspb.Message {
  getContentPlaceholdersList(): Array<ConfigContentPlaceholder>;
  setContentPlaceholdersList(value: Array<ConfigContentPlaceholder>): ListConfigContentsNotificationsResponse;
  clearContentPlaceholdersList(): ListConfigContentsNotificationsResponse;
  addContentPlaceholders(value?: ConfigContentPlaceholder, index?: number): ConfigContentPlaceholder;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListConfigContentsNotificationsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListConfigContentsNotificationsResponse): ListConfigContentsNotificationsResponse.AsObject;
  static serializeBinaryToWriter(message: ListConfigContentsNotificationsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListConfigContentsNotificationsResponse;
  static deserializeBinaryFromReader(message: ListConfigContentsNotificationsResponse, reader: jspb.BinaryReader): ListConfigContentsNotificationsResponse;
}

export namespace ListConfigContentsNotificationsResponse {
  export type AsObject = {
    contentPlaceholdersList: Array<ConfigContentPlaceholder.AsObject>,
  }
}

export class ConfigContentPlaceholder extends jspb.Message {
  getNotificationId(): string;
  setNotificationId(value: string): ConfigContentPlaceholder;

  getContentId(): string;
  setContentId(value: string): ConfigContentPlaceholder;

  getDeprecated(): boolean;
  setDeprecated(value: boolean): ConfigContentPlaceholder;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ConfigContentPlaceholder.AsObject;
  static toObject(includeInstance: boolean, msg: ConfigContentPlaceholder): ConfigContentPlaceholder.AsObject;
  static serializeBinaryToWriter(message: ConfigContentPlaceholder, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ConfigContentPlaceholder;
  static deserializeBinaryFromReader(message: ConfigContentPlaceholder, reader: jspb.BinaryReader): ConfigContentPlaceholder;
}

export namespace ConfigContentPlaceholder {
  export type AsObject = {
    notificationId: string,
    contentId: string,
    deprecated: boolean,
  }
}

export class ConfigContentNotificationRequest extends jspb.Message {
  getContentId(): string;
  setContentId(value: string): ConfigContentNotificationRequest;

  getConfigId(): string;
  setConfigId(value: string): ConfigContentNotificationRequest;

  getNotificationId(): string;
  setNotificationId(value: string): ConfigContentNotificationRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ConfigContentNotificationRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ConfigContentNotificationRequest): ConfigContentNotificationRequest.AsObject;
  static serializeBinaryToWriter(message: ConfigContentNotificationRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ConfigContentNotificationRequest;
  static deserializeBinaryFromReader(message: ConfigContentNotificationRequest, reader: jspb.BinaryReader): ConfigContentNotificationRequest;
}

export namespace ConfigContentNotificationRequest {
  export type AsObject = {
    contentId: string,
    configId: string,
    notificationId: string,
  }
}

export class ConfigContentNotificationResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ConfigContentNotificationResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ConfigContentNotificationResponse): ConfigContentNotificationResponse.AsObject;
  static serializeBinaryToWriter(message: ConfigContentNotificationResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ConfigContentNotificationResponse;
  static deserializeBinaryFromReader(message: ConfigContentNotificationResponse, reader: jspb.BinaryReader): ConfigContentNotificationResponse;
}

export namespace ConfigContentNotificationResponse {
  export type AsObject = {
  }
}

export class CopyAllConfigContentNotificationsRequest extends jspb.Message {
  getSourceConfigId(): string;
  setSourceConfigId(value: string): CopyAllConfigContentNotificationsRequest;

  getTargetConfigId(): string;
  setTargetConfigId(value: string): CopyAllConfigContentNotificationsRequest;

  getSourceNotificationIdsList(): Array<string>;
  setSourceNotificationIdsList(value: Array<string>): CopyAllConfigContentNotificationsRequest;
  clearSourceNotificationIdsList(): CopyAllConfigContentNotificationsRequest;
  addSourceNotificationIds(value: string, index?: number): CopyAllConfigContentNotificationsRequest;

  getTargetNotificationIdsList(): Array<string>;
  setTargetNotificationIdsList(value: Array<string>): CopyAllConfigContentNotificationsRequest;
  clearTargetNotificationIdsList(): CopyAllConfigContentNotificationsRequest;
  addTargetNotificationIds(value: string, index?: number): CopyAllConfigContentNotificationsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CopyAllConfigContentNotificationsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CopyAllConfigContentNotificationsRequest): CopyAllConfigContentNotificationsRequest.AsObject;
  static serializeBinaryToWriter(message: CopyAllConfigContentNotificationsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CopyAllConfigContentNotificationsRequest;
  static deserializeBinaryFromReader(message: CopyAllConfigContentNotificationsRequest, reader: jspb.BinaryReader): CopyAllConfigContentNotificationsRequest;
}

export namespace CopyAllConfigContentNotificationsRequest {
  export type AsObject = {
    sourceConfigId: string,
    targetConfigId: string,
    sourceNotificationIdsList: Array<string>,
    targetNotificationIdsList: Array<string>,
  }
}

export class CopyAllConfigContentNotificationsResponse extends jspb.Message {
  getOriginalIdsList(): Array<string>;
  setOriginalIdsList(value: Array<string>): CopyAllConfigContentNotificationsResponse;
  clearOriginalIdsList(): CopyAllConfigContentNotificationsResponse;
  addOriginalIds(value: string, index?: number): CopyAllConfigContentNotificationsResponse;

  getNewIdsList(): Array<string>;
  setNewIdsList(value: Array<string>): CopyAllConfigContentNotificationsResponse;
  clearNewIdsList(): CopyAllConfigContentNotificationsResponse;
  addNewIds(value: string, index?: number): CopyAllConfigContentNotificationsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CopyAllConfigContentNotificationsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CopyAllConfigContentNotificationsResponse): CopyAllConfigContentNotificationsResponse.AsObject;
  static serializeBinaryToWriter(message: CopyAllConfigContentNotificationsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CopyAllConfigContentNotificationsResponse;
  static deserializeBinaryFromReader(message: CopyAllConfigContentNotificationsResponse, reader: jspb.BinaryReader): CopyAllConfigContentNotificationsResponse;
}

export namespace CopyAllConfigContentNotificationsResponse {
  export type AsObject = {
    originalIdsList: Array<string>,
    newIdsList: Array<string>,
  }
}

