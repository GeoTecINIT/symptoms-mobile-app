import * as grpcWeb from 'grpc-web';

import * as configs_contents_contents_pb from '../../configs/contents/contents_pb';


export class ContentsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_contents_contents_pb.ListContentsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.ListContentsResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.ListContentsResponse>;

  create(
    request: configs_contents_contents_pb.CreateContentRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.CreateContentResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.CreateContentResponse>;

  duplicate(
    request: configs_contents_contents_pb.DuplicateContentRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.CreateContentResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.CreateContentResponse>;

  update(
    request: configs_contents_contents_pb.UpdateContentRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.UpdateContentResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.UpdateContentResponse>;

  get(
    request: configs_contents_contents_pb.GetContentRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.Content) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.Content>;

}

export class ConfigContentsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_contents_contents_pb.ListConfigContentsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.ListConfigContentsResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.ListConfigContentsResponse>;

  add(
    request: configs_contents_contents_pb.AddConfigContentRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.AddConfigContentResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.AddConfigContentResponse>;

  move(
    request: configs_contents_contents_pb.MoveConfigContentRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.MoveConfigContentResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.MoveConfigContentResponse>;

  remove(
    request: configs_contents_contents_pb.RemoveConfigContentRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.RemoveConfigContentResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.RemoveConfigContentResponse>;

}

export class ConfigContentsNotificationsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_contents_contents_pb.ListConfigContentsNotificationsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.ListConfigContentsNotificationsResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.ListConfigContentsNotificationsResponse>;

  bind(
    request: configs_contents_contents_pb.ConfigContentNotificationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.ConfigContentNotificationResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.ConfigContentNotificationResponse>;

  unbind(
    request: configs_contents_contents_pb.ConfigContentNotificationRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.ConfigContentNotificationResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.ConfigContentNotificationResponse>;

  copyAll(
    request: configs_contents_contents_pb.CopyAllConfigContentNotificationsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: configs_contents_contents_pb.CopyAllConfigContentNotificationsResponse) => void
  ): grpcWeb.ClientReadableStream<configs_contents_contents_pb.CopyAllConfigContentNotificationsResponse>;

}

export class ContentsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_contents_contents_pb.ListContentsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.ListContentsResponse>;

  create(
    request: configs_contents_contents_pb.CreateContentRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.CreateContentResponse>;

  duplicate(
    request: configs_contents_contents_pb.DuplicateContentRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.CreateContentResponse>;

  update(
    request: configs_contents_contents_pb.UpdateContentRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.UpdateContentResponse>;

  get(
    request: configs_contents_contents_pb.GetContentRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.Content>;

}

export class ConfigContentsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_contents_contents_pb.ListConfigContentsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.ListConfigContentsResponse>;

  add(
    request: configs_contents_contents_pb.AddConfigContentRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.AddConfigContentResponse>;

  move(
    request: configs_contents_contents_pb.MoveConfigContentRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.MoveConfigContentResponse>;

  remove(
    request: configs_contents_contents_pb.RemoveConfigContentRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.RemoveConfigContentResponse>;

}

export class ConfigContentsNotificationsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: configs_contents_contents_pb.ListConfigContentsNotificationsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.ListConfigContentsNotificationsResponse>;

  bind(
    request: configs_contents_contents_pb.ConfigContentNotificationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.ConfigContentNotificationResponse>;

  unbind(
    request: configs_contents_contents_pb.ConfigContentNotificationRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.ConfigContentNotificationResponse>;

  copyAll(
    request: configs_contents_contents_pb.CopyAllConfigContentNotificationsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<configs_contents_contents_pb.CopyAllConfigContentNotificationsResponse>;

}

