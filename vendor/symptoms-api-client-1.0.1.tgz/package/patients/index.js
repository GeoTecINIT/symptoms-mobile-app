export * from "./patients_pb";
export * from "./patients_grpc_web_pb";
//# sourceMappingURL=index.js.map