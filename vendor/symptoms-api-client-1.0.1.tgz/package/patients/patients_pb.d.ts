import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb';


export class ListPatientsRequest extends jspb.Message {
  getCentreId(): string;
  setCentreId(value: string): ListPatientsRequest;
  hasCentreId(): boolean;
  clearCentreId(): ListPatientsRequest;

  getStudyId(): string;
  setStudyId(value: string): ListPatientsRequest;
  hasStudyId(): boolean;
  clearStudyId(): ListPatientsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListPatientsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListPatientsRequest): ListPatientsRequest.AsObject;
  static serializeBinaryToWriter(message: ListPatientsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListPatientsRequest;
  static deserializeBinaryFromReader(message: ListPatientsRequest, reader: jspb.BinaryReader): ListPatientsRequest;
}

export namespace ListPatientsRequest {
  export type AsObject = {
    centreId?: string,
    studyId?: string,
  }

  export enum CentreIdCase { 
    _CENTRE_ID_NOT_SET = 0,
    CENTRE_ID = 1,
  }

  export enum StudyIdCase { 
    _STUDY_ID_NOT_SET = 0,
    STUDY_ID = 2,
  }
}

export class ListPatientsResponse extends jspb.Message {
  getPatientsList(): Array<Patient>;
  setPatientsList(value: Array<Patient>): ListPatientsResponse;
  clearPatientsList(): ListPatientsResponse;
  addPatients(value?: Patient, index?: number): Patient;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListPatientsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListPatientsResponse): ListPatientsResponse.AsObject;
  static serializeBinaryToWriter(message: ListPatientsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListPatientsResponse;
  static deserializeBinaryFromReader(message: ListPatientsResponse, reader: jspb.BinaryReader): ListPatientsResponse;
}

export namespace ListPatientsResponse {
  export type AsObject = {
    patientsList: Array<Patient.AsObject>,
  }
}

export class Patient extends jspb.Message {
  getId(): string;
  setId(value: string): Patient;

  getCentreId(): string;
  setCentreId(value: string): Patient;

  getTherapistId(): string;
  setTherapistId(value: string): Patient;

  getStartDate(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setStartDate(value?: google_protobuf_timestamp_pb.Timestamp): Patient;
  hasStartDate(): boolean;
  clearStartDate(): Patient;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Patient.AsObject;
  static toObject(includeInstance: boolean, msg: Patient): Patient.AsObject;
  static serializeBinaryToWriter(message: Patient, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Patient;
  static deserializeBinaryFromReader(message: Patient, reader: jspb.BinaryReader): Patient;
}

export namespace Patient {
  export type AsObject = {
    id: string,
    centreId: string,
    therapistId: string,
    startDate?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class CreatePatientRequest extends jspb.Message {
  getFileId(): string;
  setFileId(value: string): CreatePatientRequest;

  getStudyId(): string;
  setStudyId(value: string): CreatePatientRequest;
  hasStudyId(): boolean;
  clearStudyId(): CreatePatientRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreatePatientRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreatePatientRequest): CreatePatientRequest.AsObject;
  static serializeBinaryToWriter(message: CreatePatientRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreatePatientRequest;
  static deserializeBinaryFromReader(message: CreatePatientRequest, reader: jspb.BinaryReader): CreatePatientRequest;
}

export namespace CreatePatientRequest {
  export type AsObject = {
    fileId: string,
    studyId?: string,
  }

  export enum StudyIdCase { 
    _STUDY_ID_NOT_SET = 0,
    STUDY_ID = 2,
  }
}

export class CreatePatientResponse extends jspb.Message {
  getId(): string;
  setId(value: string): CreatePatientResponse;

  getStudyId(): string;
  setStudyId(value: string): CreatePatientResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreatePatientResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CreatePatientResponse): CreatePatientResponse.AsObject;
  static serializeBinaryToWriter(message: CreatePatientResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreatePatientResponse;
  static deserializeBinaryFromReader(message: CreatePatientResponse, reader: jspb.BinaryReader): CreatePatientResponse;
}

export namespace CreatePatientResponse {
  export type AsObject = {
    id: string,
    studyId: string,
  }
}

export class UpdatePatientRequest extends jspb.Message {
  getId(): string;
  setId(value: string): UpdatePatientRequest;

  getFileId(): string;
  setFileId(value: string): UpdatePatientRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdatePatientRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdatePatientRequest): UpdatePatientRequest.AsObject;
  static serializeBinaryToWriter(message: UpdatePatientRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdatePatientRequest;
  static deserializeBinaryFromReader(message: UpdatePatientRequest, reader: jspb.BinaryReader): UpdatePatientRequest;
}

export namespace UpdatePatientRequest {
  export type AsObject = {
    id: string,
    fileId: string,
  }
}

export class UpdatePatientResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdatePatientResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdatePatientResponse): UpdatePatientResponse.AsObject;
  static serializeBinaryToWriter(message: UpdatePatientResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdatePatientResponse;
  static deserializeBinaryFromReader(message: UpdatePatientResponse, reader: jspb.BinaryReader): UpdatePatientResponse;
}

export namespace UpdatePatientResponse {
  export type AsObject = {
  }
}

export class ActivatePatientRequest extends jspb.Message {
  getId(): string;
  setId(value: string): ActivatePatientRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ActivatePatientRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ActivatePatientRequest): ActivatePatientRequest.AsObject;
  static serializeBinaryToWriter(message: ActivatePatientRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ActivatePatientRequest;
  static deserializeBinaryFromReader(message: ActivatePatientRequest, reader: jspb.BinaryReader): ActivatePatientRequest;
}

export namespace ActivatePatientRequest {
  export type AsObject = {
    id: string,
  }
}

export class ActivatePatientResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ActivatePatientResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ActivatePatientResponse): ActivatePatientResponse.AsObject;
  static serializeBinaryToWriter(message: ActivatePatientResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ActivatePatientResponse;
  static deserializeBinaryFromReader(message: ActivatePatientResponse, reader: jspb.BinaryReader): ActivatePatientResponse;
}

export namespace ActivatePatientResponse {
  export type AsObject = {
  }
}

export class DeactivatePatientRequest extends jspb.Message {
  getId(): string;
  setId(value: string): DeactivatePatientRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeactivatePatientRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeactivatePatientRequest): DeactivatePatientRequest.AsObject;
  static serializeBinaryToWriter(message: DeactivatePatientRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeactivatePatientRequest;
  static deserializeBinaryFromReader(message: DeactivatePatientRequest, reader: jspb.BinaryReader): DeactivatePatientRequest;
}

export namespace DeactivatePatientRequest {
  export type AsObject = {
    id: string,
  }
}

export class DeactivatePatientResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeactivatePatientResponse.AsObject;
  static toObject(includeInstance: boolean, msg: DeactivatePatientResponse): DeactivatePatientResponse.AsObject;
  static serializeBinaryToWriter(message: DeactivatePatientResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeactivatePatientResponse;
  static deserializeBinaryFromReader(message: DeactivatePatientResponse, reader: jspb.BinaryReader): DeactivatePatientResponse;
}

export namespace DeactivatePatientResponse {
  export type AsObject = {
  }
}

export class GetPatientRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetPatientRequest;

  getStudyId(): string;
  setStudyId(value: string): GetPatientRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetPatientRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetPatientRequest): GetPatientRequest.AsObject;
  static serializeBinaryToWriter(message: GetPatientRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetPatientRequest;
  static deserializeBinaryFromReader(message: GetPatientRequest, reader: jspb.BinaryReader): GetPatientRequest;
}

export namespace GetPatientRequest {
  export type AsObject = {
    id: string,
    studyId: string,
  }
}

export class UpdateConsentRequest extends jspb.Message {
  getDataSharing(): boolean;
  setDataSharing(value: boolean): UpdateConsentRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateConsentRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateConsentRequest): UpdateConsentRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateConsentRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateConsentRequest;
  static deserializeBinaryFromReader(message: UpdateConsentRequest, reader: jspb.BinaryReader): UpdateConsentRequest;
}

export namespace UpdateConsentRequest {
  export type AsObject = {
    dataSharing: boolean,
  }
}

export class UpdateConsentResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateConsentResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateConsentResponse): UpdateConsentResponse.AsObject;
  static serializeBinaryToWriter(message: UpdateConsentResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateConsentResponse;
  static deserializeBinaryFromReader(message: UpdateConsentResponse, reader: jspb.BinaryReader): UpdateConsentResponse;
}

export namespace UpdateConsentResponse {
  export type AsObject = {
  }
}

export class GetConsentRequest extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetConsentRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetConsentRequest): GetConsentRequest.AsObject;
  static serializeBinaryToWriter(message: GetConsentRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetConsentRequest;
  static deserializeBinaryFromReader(message: GetConsentRequest, reader: jspb.BinaryReader): GetConsentRequest;
}

export namespace GetConsentRequest {
  export type AsObject = {
  }
}

export class GetConsentResponse extends jspb.Message {
  getDataSharing(): boolean;
  setDataSharing(value: boolean): GetConsentResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetConsentResponse.AsObject;
  static toObject(includeInstance: boolean, msg: GetConsentResponse): GetConsentResponse.AsObject;
  static serializeBinaryToWriter(message: GetConsentResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetConsentResponse;
  static deserializeBinaryFromReader(message: GetConsentResponse, reader: jspb.BinaryReader): GetConsentResponse;
}

export namespace GetConsentResponse {
  export type AsObject = {
    dataSharing: boolean,
  }
}

export class ChangeStudyRequest extends jspb.Message {
  getId(): string;
  setId(value: string): ChangeStudyRequest;

  getStudyId(): string;
  setStudyId(value: string): ChangeStudyRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ChangeStudyRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ChangeStudyRequest): ChangeStudyRequest.AsObject;
  static serializeBinaryToWriter(message: ChangeStudyRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ChangeStudyRequest;
  static deserializeBinaryFromReader(message: ChangeStudyRequest, reader: jspb.BinaryReader): ChangeStudyRequest;
}

export namespace ChangeStudyRequest {
  export type AsObject = {
    id: string,
    studyId: string,
  }
}

export class ChangeStudyResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ChangeStudyResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ChangeStudyResponse): ChangeStudyResponse.AsObject;
  static serializeBinaryToWriter(message: ChangeStudyResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ChangeStudyResponse;
  static deserializeBinaryFromReader(message: ChangeStudyResponse, reader: jspb.BinaryReader): ChangeStudyResponse;
}

export namespace ChangeStudyResponse {
  export type AsObject = {
  }
}

