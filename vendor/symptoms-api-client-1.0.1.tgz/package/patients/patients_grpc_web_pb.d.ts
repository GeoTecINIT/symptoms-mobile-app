import * as grpcWeb from 'grpc-web';

import * as patients_patients_pb from '../patients/patients_pb';


export class PatientsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: patients_patients_pb.ListPatientsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: patients_patients_pb.ListPatientsResponse) => void
  ): grpcWeb.ClientReadableStream<patients_patients_pb.ListPatientsResponse>;

  create(
    request: patients_patients_pb.CreatePatientRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: patients_patients_pb.CreatePatientResponse) => void
  ): grpcWeb.ClientReadableStream<patients_patients_pb.CreatePatientResponse>;

  update(
    request: patients_patients_pb.UpdatePatientRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: patients_patients_pb.UpdatePatientResponse) => void
  ): grpcWeb.ClientReadableStream<patients_patients_pb.UpdatePatientResponse>;

  activate(
    request: patients_patients_pb.ActivatePatientRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: patients_patients_pb.ActivatePatientResponse) => void
  ): grpcWeb.ClientReadableStream<patients_patients_pb.ActivatePatientResponse>;

  deactivate(
    request: patients_patients_pb.DeactivatePatientRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: patients_patients_pb.DeactivatePatientResponse) => void
  ): grpcWeb.ClientReadableStream<patients_patients_pb.DeactivatePatientResponse>;

  get(
    request: patients_patients_pb.GetPatientRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: patients_patients_pb.Patient) => void
  ): grpcWeb.ClientReadableStream<patients_patients_pb.Patient>;

  updateConsent(
    request: patients_patients_pb.UpdateConsentRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: patients_patients_pb.UpdateConsentResponse) => void
  ): grpcWeb.ClientReadableStream<patients_patients_pb.UpdateConsentResponse>;

  getConsent(
    request: patients_patients_pb.GetConsentRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: patients_patients_pb.GetConsentResponse) => void
  ): grpcWeb.ClientReadableStream<patients_patients_pb.GetConsentResponse>;

  changeStudy(
    request: patients_patients_pb.ChangeStudyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: patients_patients_pb.ChangeStudyResponse) => void
  ): grpcWeb.ClientReadableStream<patients_patients_pb.ChangeStudyResponse>;

}

export class PatientsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: patients_patients_pb.ListPatientsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<patients_patients_pb.ListPatientsResponse>;

  create(
    request: patients_patients_pb.CreatePatientRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<patients_patients_pb.CreatePatientResponse>;

  update(
    request: patients_patients_pb.UpdatePatientRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<patients_patients_pb.UpdatePatientResponse>;

  activate(
    request: patients_patients_pb.ActivatePatientRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<patients_patients_pb.ActivatePatientResponse>;

  deactivate(
    request: patients_patients_pb.DeactivatePatientRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<patients_patients_pb.DeactivatePatientResponse>;

  get(
    request: patients_patients_pb.GetPatientRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<patients_patients_pb.Patient>;

  updateConsent(
    request: patients_patients_pb.UpdateConsentRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<patients_patients_pb.UpdateConsentResponse>;

  getConsent(
    request: patients_patients_pb.GetConsentRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<patients_patients_pb.GetConsentResponse>;

  changeStudy(
    request: patients_patients_pb.ChangeStudyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<patients_patients_pb.ChangeStudyResponse>;

}

