import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb';


export class Record extends jspb.Message {
  getId(): string;
  setId(value: string): Record;

  getType(): string;
  setType(value: string): Record;

  getTimestamp(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setTimestamp(value?: google_protobuf_timestamp_pb.Timestamp): Record;
  hasTimestamp(): boolean;
  clearTimestamp(): Record;

  getTzOffset(): number;
  setTzOffset(value: number): Record;

  getDeviceId(): string;
  setDeviceId(value: string): Record;
  hasDeviceId(): boolean;
  clearDeviceId(): Record;

  getChange(): Record.Change;
  setChange(value: Record.Change): Record;

  getPayload(): string;
  setPayload(value: string): Record;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Record.AsObject;
  static toObject(includeInstance: boolean, msg: Record): Record.AsObject;
  static serializeBinaryToWriter(message: Record, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Record;
  static deserializeBinaryFromReader(message: Record, reader: jspb.BinaryReader): Record;
}

export namespace Record {
  export type AsObject = {
    id: string,
    type: string,
    timestamp?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    tzOffset: number,
    deviceId?: string,
    change: Record.Change,
    payload: string,
  }

  export enum Change { 
    NONE = 0,
    START = 1,
    END = 2,
  }

  export enum DeviceIdCase { 
    _DEVICE_ID_NOT_SET = 0,
    DEVICE_ID = 5,
  }
}

export enum RecordSource { 
  PATIENT = 0,
  THERAPIST = 1,
  ANALYSIS = 2,
}
