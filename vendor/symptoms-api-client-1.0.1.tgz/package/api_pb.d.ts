import * as jspb from 'google-protobuf'

import * as centres_centres_pb from './centres/centres_pb';
import * as therapists_therapists_pb from './therapists/therapists_pb';
import * as studies_studies_pb from './studies/studies_pb';
import * as studies_places_places_pb from './studies/places/places_pb';
import * as patients_patients_pb from './patients/patients_pb';
import * as configs_configs_pb from './configs/configs_pb';
import * as configs_contents_contents_pb from './configs/contents/contents_pb';
import * as configs_notifications_notifications_pb from './configs/notifications/notifications_pb';
import * as configs_workflows_workflows_pb from './configs/workflows/workflows_pb';
import * as devices_devices_pb from './devices/devices_pb';
import * as uploads_uploads_pb from './uploads/uploads_pb';
import * as queries_queries_pb from './queries/queries_pb';


