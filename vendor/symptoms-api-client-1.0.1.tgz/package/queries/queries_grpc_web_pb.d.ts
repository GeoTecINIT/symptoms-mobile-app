import * as grpcWeb from 'grpc-web';

import * as queries_queries_pb from '../queries/queries_pb';
import * as records_records_pb from '../records/records_pb';


export class RecordQueriesClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  hasUploaded(
    request: queries_queries_pb.HasUploadedRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: queries_queries_pb.HasUploadedResponse) => void
  ): grpcWeb.ClientReadableStream<queries_queries_pb.HasUploadedResponse>;

  getRange(
    request: queries_queries_pb.GetRangeRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: queries_queries_pb.GetRangeResponse) => void
  ): grpcWeb.ClientReadableStream<queries_queries_pb.GetRangeResponse>;

  getLast(
    request: queries_queries_pb.GetLastRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: records_records_pb.Record) => void
  ): grpcWeb.ClientReadableStream<records_records_pb.Record>;

  getAll(
    request: queries_queries_pb.GetAllRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: queries_queries_pb.GetManyResponse) => void
  ): grpcWeb.ClientReadableStream<queries_queries_pb.GetManyResponse>;

  getLastGrouped(
    request: queries_queries_pb.GetLastGroupedRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: queries_queries_pb.GetManyResponse) => void
  ): grpcWeb.ClientReadableStream<queries_queries_pb.GetManyResponse>;

}

export class RecordQueriesPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  hasUploaded(
    request: queries_queries_pb.HasUploadedRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<queries_queries_pb.HasUploadedResponse>;

  getRange(
    request: queries_queries_pb.GetRangeRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<queries_queries_pb.GetRangeResponse>;

  getLast(
    request: queries_queries_pb.GetLastRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<records_records_pb.Record>;

  getAll(
    request: queries_queries_pb.GetAllRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<queries_queries_pb.GetManyResponse>;

  getLastGrouped(
    request: queries_queries_pb.GetLastGroupedRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<queries_queries_pb.GetManyResponse>;

}

