import * as jspb from 'google-protobuf'

import * as google_protobuf_any_pb from 'google-protobuf/google/protobuf/any_pb';
import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb';
import * as records_records_pb from '../records/records_pb';


export class HasUploadedRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): HasUploadedRequest;

  getStudyId(): string;
  setStudyId(value: string): HasUploadedRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): HasUploadedRequest.AsObject;
  static toObject(includeInstance: boolean, msg: HasUploadedRequest): HasUploadedRequest.AsObject;
  static serializeBinaryToWriter(message: HasUploadedRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): HasUploadedRequest;
  static deserializeBinaryFromReader(message: HasUploadedRequest, reader: jspb.BinaryReader): HasUploadedRequest;
}

export namespace HasUploadedRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
  }
}

export class HasUploadedResponse extends jspb.Message {
  getUploaded(): boolean;
  setUploaded(value: boolean): HasUploadedResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): HasUploadedResponse.AsObject;
  static toObject(includeInstance: boolean, msg: HasUploadedResponse): HasUploadedResponse.AsObject;
  static serializeBinaryToWriter(message: HasUploadedResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): HasUploadedResponse;
  static deserializeBinaryFromReader(message: HasUploadedResponse, reader: jspb.BinaryReader): HasUploadedResponse;
}

export namespace HasUploadedResponse {
  export type AsObject = {
    uploaded: boolean,
  }
}

export class GetRangeRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): GetRangeRequest;

  getStudyId(): string;
  setStudyId(value: string): GetRangeRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetRangeRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetRangeRequest): GetRangeRequest.AsObject;
  static serializeBinaryToWriter(message: GetRangeRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetRangeRequest;
  static deserializeBinaryFromReader(message: GetRangeRequest, reader: jspb.BinaryReader): GetRangeRequest;
}

export namespace GetRangeRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
  }
}

export class GetRangeResponse extends jspb.Message {
  getStartsAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setStartsAt(value?: google_protobuf_timestamp_pb.Timestamp): GetRangeResponse;
  hasStartsAt(): boolean;
  clearStartsAt(): GetRangeResponse;

  getEndsAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setEndsAt(value?: google_protobuf_timestamp_pb.Timestamp): GetRangeResponse;
  hasEndsAt(): boolean;
  clearEndsAt(): GetRangeResponse;

  getTzOffset(): number;
  setTzOffset(value: number): GetRangeResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetRangeResponse.AsObject;
  static toObject(includeInstance: boolean, msg: GetRangeResponse): GetRangeResponse.AsObject;
  static serializeBinaryToWriter(message: GetRangeResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetRangeResponse;
  static deserializeBinaryFromReader(message: GetRangeResponse, reader: jspb.BinaryReader): GetRangeResponse;
}

export namespace GetRangeResponse {
  export type AsObject = {
    startsAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    endsAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    tzOffset: number,
  }
}

export class GetLastRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): GetLastRequest;

  getStudyId(): string;
  setStudyId(value: string): GetLastRequest;

  getRecordType(): string;
  setRecordType(value: string): GetLastRequest;
  hasRecordType(): boolean;
  clearRecordType(): GetLastRequest;

  getConditionsList(): Array<QueryCondition>;
  setConditionsList(value: Array<QueryCondition>): GetLastRequest;
  clearConditionsList(): GetLastRequest;
  addConditions(value?: QueryCondition, index?: number): QueryCondition;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetLastRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetLastRequest): GetLastRequest.AsObject;
  static serializeBinaryToWriter(message: GetLastRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetLastRequest;
  static deserializeBinaryFromReader(message: GetLastRequest, reader: jspb.BinaryReader): GetLastRequest;
}

export namespace GetLastRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    recordType?: string,
    conditionsList: Array<QueryCondition.AsObject>,
  }

  export enum RecordTypeCase { 
    _RECORD_TYPE_NOT_SET = 0,
    RECORD_TYPE = 3,
  }
}

export class GetAllRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): GetAllRequest;

  getStudyId(): string;
  setStudyId(value: string): GetAllRequest;

  getRecordType(): string;
  setRecordType(value: string): GetAllRequest;
  hasRecordType(): boolean;
  clearRecordType(): GetAllRequest;

  getConditionsList(): Array<QueryCondition>;
  setConditionsList(value: Array<QueryCondition>): GetAllRequest;
  clearConditionsList(): GetAllRequest;
  addConditions(value?: QueryCondition, index?: number): QueryCondition;

  getOrder(): QueryOrder;
  setOrder(value: QueryOrder): GetAllRequest;

  getStartAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setStartAt(value?: google_protobuf_timestamp_pb.Timestamp): GetAllRequest;
  hasStartAt(): boolean;
  clearStartAt(): GetAllRequest;

  getEndAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setEndAt(value?: google_protobuf_timestamp_pb.Timestamp): GetAllRequest;
  hasEndAt(): boolean;
  clearEndAt(): GetAllRequest;

  getTzOffset(): number;
  setTzOffset(value: number): GetAllRequest;
  hasTzOffset(): boolean;
  clearTzOffset(): GetAllRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetAllRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetAllRequest): GetAllRequest.AsObject;
  static serializeBinaryToWriter(message: GetAllRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetAllRequest;
  static deserializeBinaryFromReader(message: GetAllRequest, reader: jspb.BinaryReader): GetAllRequest;
}

export namespace GetAllRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    recordType?: string,
    conditionsList: Array<QueryCondition.AsObject>,
    order: QueryOrder,
    startAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    endAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    tzOffset?: number,
  }

  export enum RecordTypeCase { 
    _RECORD_TYPE_NOT_SET = 0,
    RECORD_TYPE = 3,
  }

  export enum StartAtCase { 
    _START_AT_NOT_SET = 0,
    START_AT = 6,
  }

  export enum EndAtCase { 
    _END_AT_NOT_SET = 0,
    END_AT = 7,
  }

  export enum TzOffsetCase { 
    _TZ_OFFSET_NOT_SET = 0,
    TZ_OFFSET = 8,
  }
}

export class GetManyResponse extends jspb.Message {
  getRecordsList(): Array<records_records_pb.Record>;
  setRecordsList(value: Array<records_records_pb.Record>): GetManyResponse;
  clearRecordsList(): GetManyResponse;
  addRecords(value?: records_records_pb.Record, index?: number): records_records_pb.Record;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetManyResponse.AsObject;
  static toObject(includeInstance: boolean, msg: GetManyResponse): GetManyResponse.AsObject;
  static serializeBinaryToWriter(message: GetManyResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetManyResponse;
  static deserializeBinaryFromReader(message: GetManyResponse, reader: jspb.BinaryReader): GetManyResponse;
}

export namespace GetManyResponse {
  export type AsObject = {
    recordsList: Array<records_records_pb.Record.AsObject>,
  }
}

export class GetLastGroupedRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): GetLastGroupedRequest;

  getStudyId(): string;
  setStudyId(value: string): GetLastGroupedRequest;

  getRecordType(): string;
  setRecordType(value: string): GetLastGroupedRequest;

  getConditionsList(): Array<QueryCondition>;
  setConditionsList(value: Array<QueryCondition>): GetLastGroupedRequest;
  clearConditionsList(): GetLastGroupedRequest;
  addConditions(value?: QueryCondition, index?: number): QueryCondition;

  getOrder(): QueryOrder;
  setOrder(value: QueryOrder): GetLastGroupedRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetLastGroupedRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetLastGroupedRequest): GetLastGroupedRequest.AsObject;
  static serializeBinaryToWriter(message: GetLastGroupedRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetLastGroupedRequest;
  static deserializeBinaryFromReader(message: GetLastGroupedRequest, reader: jspb.BinaryReader): GetLastGroupedRequest;
}

export namespace GetLastGroupedRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    recordType: string,
    conditionsList: Array<QueryCondition.AsObject>,
    order: QueryOrder,
  }
}

export class QueryCondition extends jspb.Message {
  getProperty(): string;
  setProperty(value: string): QueryCondition;

  getComparison(): QueryCondition.Comparison;
  setComparison(value: QueryCondition.Comparison): QueryCondition;

  getValue(): google_protobuf_any_pb.Any | undefined;
  setValue(value?: google_protobuf_any_pb.Any): QueryCondition;
  hasValue(): boolean;
  clearValue(): QueryCondition;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): QueryCondition.AsObject;
  static toObject(includeInstance: boolean, msg: QueryCondition): QueryCondition.AsObject;
  static serializeBinaryToWriter(message: QueryCondition, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): QueryCondition;
  static deserializeBinaryFromReader(message: QueryCondition, reader: jspb.BinaryReader): QueryCondition;
}

export namespace QueryCondition {
  export type AsObject = {
    property: string,
    comparison: QueryCondition.Comparison,
    value?: google_protobuf_any_pb.Any.AsObject,
  }

  export enum Comparison { 
    EQUAL_TO = 0,
  }
}

export class StringValue extends jspb.Message {
  getValue(): string;
  setValue(value: string): StringValue;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StringValue.AsObject;
  static toObject(includeInstance: boolean, msg: StringValue): StringValue.AsObject;
  static serializeBinaryToWriter(message: StringValue, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StringValue;
  static deserializeBinaryFromReader(message: StringValue, reader: jspb.BinaryReader): StringValue;
}

export namespace StringValue {
  export type AsObject = {
    value: string,
  }
}

export class NumberValue extends jspb.Message {
  getValue(): number;
  setValue(value: number): NumberValue;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NumberValue.AsObject;
  static toObject(includeInstance: boolean, msg: NumberValue): NumberValue.AsObject;
  static serializeBinaryToWriter(message: NumberValue, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NumberValue;
  static deserializeBinaryFromReader(message: NumberValue, reader: jspb.BinaryReader): NumberValue;
}

export namespace NumberValue {
  export type AsObject = {
    value: number,
  }
}

export class BoolValue extends jspb.Message {
  getValue(): boolean;
  setValue(value: boolean): BoolValue;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BoolValue.AsObject;
  static toObject(includeInstance: boolean, msg: BoolValue): BoolValue.AsObject;
  static serializeBinaryToWriter(message: BoolValue, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BoolValue;
  static deserializeBinaryFromReader(message: BoolValue, reader: jspb.BinaryReader): BoolValue;
}

export namespace BoolValue {
  export type AsObject = {
    value: boolean,
  }
}

export enum QueryOrder { 
  ASC = 0,
  DESC = 1,
}
