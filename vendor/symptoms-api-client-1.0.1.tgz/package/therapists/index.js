export * from "./therapists_pb";
export * from "./therapists_grpc_web_pb";
//# sourceMappingURL=index.js.map