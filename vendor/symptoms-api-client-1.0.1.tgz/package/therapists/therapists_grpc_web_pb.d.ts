import * as grpcWeb from 'grpc-web';

import * as therapists_therapists_pb from '../therapists/therapists_pb';


export class TherapistsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: therapists_therapists_pb.ListTherapistsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: therapists_therapists_pb.ListTherapistsResponse) => void
  ): grpcWeb.ClientReadableStream<therapists_therapists_pb.ListTherapistsResponse>;

  create(
    request: therapists_therapists_pb.CreateTherapistRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: therapists_therapists_pb.CreateTherapistResponse) => void
  ): grpcWeb.ClientReadableStream<therapists_therapists_pb.CreateTherapistResponse>;

  update(
    request: therapists_therapists_pb.UpdateTherapistRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: therapists_therapists_pb.UpdateTherapistResponse) => void
  ): grpcWeb.ClientReadableStream<therapists_therapists_pb.UpdateTherapistResponse>;

  get(
    request: therapists_therapists_pb.GetTherapistRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: therapists_therapists_pb.Therapist) => void
  ): grpcWeb.ClientReadableStream<therapists_therapists_pb.Therapist>;

  promote(
    request: therapists_therapists_pb.PromoteTherapistRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: therapists_therapists_pb.PromoteTherapistResponse) => void
  ): grpcWeb.ClientReadableStream<therapists_therapists_pb.PromoteTherapistResponse>;

  degrade(
    request: therapists_therapists_pb.DegradeTherapistRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: therapists_therapists_pb.DegradeTherapistResponse) => void
  ): grpcWeb.ClientReadableStream<therapists_therapists_pb.DegradeTherapistResponse>;

}

export class TherapistsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: therapists_therapists_pb.ListTherapistsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<therapists_therapists_pb.ListTherapistsResponse>;

  create(
    request: therapists_therapists_pb.CreateTherapistRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<therapists_therapists_pb.CreateTherapistResponse>;

  update(
    request: therapists_therapists_pb.UpdateTherapistRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<therapists_therapists_pb.UpdateTherapistResponse>;

  get(
    request: therapists_therapists_pb.GetTherapistRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<therapists_therapists_pb.Therapist>;

  promote(
    request: therapists_therapists_pb.PromoteTherapistRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<therapists_therapists_pb.PromoteTherapistResponse>;

  degrade(
    request: therapists_therapists_pb.DegradeTherapistRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<therapists_therapists_pb.DegradeTherapistResponse>;

}

