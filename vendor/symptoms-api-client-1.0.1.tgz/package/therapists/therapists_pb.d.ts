import * as jspb from 'google-protobuf'



export class ListTherapistsRequest extends jspb.Message {
  getCentreId(): string;
  setCentreId(value: string): ListTherapistsRequest;
  hasCentreId(): boolean;
  clearCentreId(): ListTherapistsRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListTherapistsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListTherapistsRequest): ListTherapistsRequest.AsObject;
  static serializeBinaryToWriter(message: ListTherapistsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListTherapistsRequest;
  static deserializeBinaryFromReader(message: ListTherapistsRequest, reader: jspb.BinaryReader): ListTherapistsRequest;
}

export namespace ListTherapistsRequest {
  export type AsObject = {
    centreId?: string,
  }

  export enum CentreIdCase { 
    _CENTRE_ID_NOT_SET = 0,
    CENTRE_ID = 1,
  }
}

export class ListTherapistsResponse extends jspb.Message {
  getTherapistsList(): Array<Therapist>;
  setTherapistsList(value: Array<Therapist>): ListTherapistsResponse;
  clearTherapistsList(): ListTherapistsResponse;
  addTherapists(value?: Therapist, index?: number): Therapist;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListTherapistsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListTherapistsResponse): ListTherapistsResponse.AsObject;
  static serializeBinaryToWriter(message: ListTherapistsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListTherapistsResponse;
  static deserializeBinaryFromReader(message: ListTherapistsResponse, reader: jspb.BinaryReader): ListTherapistsResponse;
}

export namespace ListTherapistsResponse {
  export type AsObject = {
    therapistsList: Array<Therapist.AsObject>,
  }
}

export class Therapist extends jspb.Message {
  getId(): string;
  setId(value: string): Therapist;

  getFullname(): string;
  setFullname(value: string): Therapist;

  getEmail(): string;
  setEmail(value: string): Therapist;

  getWorkPhone(): string;
  setWorkPhone(value: string): Therapist;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Therapist.AsObject;
  static toObject(includeInstance: boolean, msg: Therapist): Therapist.AsObject;
  static serializeBinaryToWriter(message: Therapist, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Therapist;
  static deserializeBinaryFromReader(message: Therapist, reader: jspb.BinaryReader): Therapist;
}

export namespace Therapist {
  export type AsObject = {
    id: string,
    fullname: string,
    email: string,
    workPhone: string,
  }
}

export class CreateTherapistRequest extends jspb.Message {
  getAuthId(): string;
  setAuthId(value: string): CreateTherapistRequest;
  hasAuthId(): boolean;
  clearAuthId(): CreateTherapistRequest;

  getFirstName(): string;
  setFirstName(value: string): CreateTherapistRequest;

  getLastName(): string;
  setLastName(value: string): CreateTherapistRequest;

  getEmail(): string;
  setEmail(value: string): CreateTherapistRequest;

  getWorkPhone(): string;
  setWorkPhone(value: string): CreateTherapistRequest;

  getCentreId(): string;
  setCentreId(value: string): CreateTherapistRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateTherapistRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateTherapistRequest): CreateTherapistRequest.AsObject;
  static serializeBinaryToWriter(message: CreateTherapistRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateTherapistRequest;
  static deserializeBinaryFromReader(message: CreateTherapistRequest, reader: jspb.BinaryReader): CreateTherapistRequest;
}

export namespace CreateTherapistRequest {
  export type AsObject = {
    authId?: string,
    firstName: string,
    lastName: string,
    email: string,
    workPhone: string,
    centreId: string,
  }

  export enum AuthIdCase { 
    _AUTH_ID_NOT_SET = 0,
    AUTH_ID = 1,
  }
}

export class CreateTherapistResponse extends jspb.Message {
  getId(): string;
  setId(value: string): CreateTherapistResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateTherapistResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CreateTherapistResponse): CreateTherapistResponse.AsObject;
  static serializeBinaryToWriter(message: CreateTherapistResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateTherapistResponse;
  static deserializeBinaryFromReader(message: CreateTherapistResponse, reader: jspb.BinaryReader): CreateTherapistResponse;
}

export namespace CreateTherapistResponse {
  export type AsObject = {
    id: string,
  }
}

export class UpdateTherapistRequest extends jspb.Message {
  getId(): string;
  setId(value: string): UpdateTherapistRequest;
  hasId(): boolean;
  clearId(): UpdateTherapistRequest;

  getFirstName(): string;
  setFirstName(value: string): UpdateTherapistRequest;

  getLastName(): string;
  setLastName(value: string): UpdateTherapistRequest;

  getWorkPhone(): string;
  setWorkPhone(value: string): UpdateTherapistRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateTherapistRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateTherapistRequest): UpdateTherapistRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateTherapistRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateTherapistRequest;
  static deserializeBinaryFromReader(message: UpdateTherapistRequest, reader: jspb.BinaryReader): UpdateTherapistRequest;
}

export namespace UpdateTherapistRequest {
  export type AsObject = {
    id?: string,
    firstName: string,
    lastName: string,
    workPhone: string,
  }

  export enum IdCase { 
    _ID_NOT_SET = 0,
    ID = 1,
  }
}

export class UpdateTherapistResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateTherapistResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateTherapistResponse): UpdateTherapistResponse.AsObject;
  static serializeBinaryToWriter(message: UpdateTherapistResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateTherapistResponse;
  static deserializeBinaryFromReader(message: UpdateTherapistResponse, reader: jspb.BinaryReader): UpdateTherapistResponse;
}

export namespace UpdateTherapistResponse {
  export type AsObject = {
  }
}

export class GetTherapistRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetTherapistRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetTherapistRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetTherapistRequest): GetTherapistRequest.AsObject;
  static serializeBinaryToWriter(message: GetTherapistRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetTherapistRequest;
  static deserializeBinaryFromReader(message: GetTherapistRequest, reader: jspb.BinaryReader): GetTherapistRequest;
}

export namespace GetTherapistRequest {
  export type AsObject = {
    id: string,
  }
}

export class PromoteTherapistRequest extends jspb.Message {
  getId(): string;
  setId(value: string): PromoteTherapistRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PromoteTherapistRequest.AsObject;
  static toObject(includeInstance: boolean, msg: PromoteTherapistRequest): PromoteTherapistRequest.AsObject;
  static serializeBinaryToWriter(message: PromoteTherapistRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PromoteTherapistRequest;
  static deserializeBinaryFromReader(message: PromoteTherapistRequest, reader: jspb.BinaryReader): PromoteTherapistRequest;
}

export namespace PromoteTherapistRequest {
  export type AsObject = {
    id: string,
  }
}

export class PromoteTherapistResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PromoteTherapistResponse.AsObject;
  static toObject(includeInstance: boolean, msg: PromoteTherapistResponse): PromoteTherapistResponse.AsObject;
  static serializeBinaryToWriter(message: PromoteTherapistResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PromoteTherapistResponse;
  static deserializeBinaryFromReader(message: PromoteTherapistResponse, reader: jspb.BinaryReader): PromoteTherapistResponse;
}

export namespace PromoteTherapistResponse {
  export type AsObject = {
  }
}

export class DegradeTherapistRequest extends jspb.Message {
  getId(): string;
  setId(value: string): DegradeTherapistRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DegradeTherapistRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DegradeTherapistRequest): DegradeTherapistRequest.AsObject;
  static serializeBinaryToWriter(message: DegradeTherapistRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DegradeTherapistRequest;
  static deserializeBinaryFromReader(message: DegradeTherapistRequest, reader: jspb.BinaryReader): DegradeTherapistRequest;
}

export namespace DegradeTherapistRequest {
  export type AsObject = {
    id: string,
  }
}

export class DegradeTherapistResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DegradeTherapistResponse.AsObject;
  static toObject(includeInstance: boolean, msg: DegradeTherapistResponse): DegradeTherapistResponse.AsObject;
  static serializeBinaryToWriter(message: DegradeTherapistResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DegradeTherapistResponse;
  static deserializeBinaryFromReader(message: DegradeTherapistResponse, reader: jspb.BinaryReader): DegradeTherapistResponse;
}

export namespace DegradeTherapistResponse {
  export type AsObject = {
  }
}

