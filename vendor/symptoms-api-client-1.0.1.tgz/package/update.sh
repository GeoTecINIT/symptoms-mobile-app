#!/bin/bash
# Cleanup
find . \( -name "*.js" -o -name "*.ts" \) ! -name "index.ts" -exec rm {} \;
rm -rf node_modules

# Generate
DEFINITIONS_FOLDER=../../definitions
proto_files=$(../list_proto_files.sh $DEFINITIONS_FOLDER)

protoc -I=$DEFINITIONS_FOLDER \
  --js_out=import_style=commonjs:. \
  --grpc-web_out=import_style=commonjs+dts,mode=grpcwebtext:. \
  $proto_files

# Update dependencies
npm i

# Transpile to JS
npm run build
