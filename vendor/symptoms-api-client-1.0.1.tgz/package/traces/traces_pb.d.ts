import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb';


export class Trace extends jspb.Message {
  getId(): string;
  setId(value: string): Trace;

  getDeviceId(): string;
  setDeviceId(value: string): Trace;

  getTimestamp(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setTimestamp(value?: google_protobuf_timestamp_pb.Timestamp): Trace;
  hasTimestamp(): boolean;
  clearTimestamp(): Trace;

  getTzOffset(): number;
  setTzOffset(value: number): Trace;

  getChainId(): string;
  setChainId(value: string): Trace;

  getObservationName(): string;
  setObservationName(value: string): Trace;

  getType(): Trace.Type;
  setType(value: Trace.Type): Trace;

  getResult(): Trace.Result;
  setResult(value: Trace.Result): Trace;

  getPayload(): string;
  setPayload(value: string): Trace;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Trace.AsObject;
  static toObject(includeInstance: boolean, msg: Trace): Trace.AsObject;
  static serializeBinaryToWriter(message: Trace, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Trace;
  static deserializeBinaryFromReader(message: Trace, reader: jspb.BinaryReader): Trace;
}

export namespace Trace {
  export type AsObject = {
    id: string,
    deviceId: string,
    timestamp?: google_protobuf_timestamp_pb.Timestamp.AsObject,
    tzOffset: number,
    chainId: string,
    observationName: string,
    type: Trace.Type,
    result: Trace.Result,
    payload: string,
  }

  export enum Type { 
    EVENT = 0,
    TASK = 1,
  }

  export enum Result { 
    OK = 0,
    ERROR = 1,
  }
}

