import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb';


export class ListDevicesRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): ListDevicesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListDevicesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListDevicesRequest): ListDevicesRequest.AsObject;
  static serializeBinaryToWriter(message: ListDevicesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListDevicesRequest;
  static deserializeBinaryFromReader(message: ListDevicesRequest, reader: jspb.BinaryReader): ListDevicesRequest;
}

export namespace ListDevicesRequest {
  export type AsObject = {
    patientId: string,
  }
}

export class ListDevicesResponse extends jspb.Message {
  getDevicesList(): Array<Device>;
  setDevicesList(value: Array<Device>): ListDevicesResponse;
  clearDevicesList(): ListDevicesResponse;
  addDevices(value?: Device, index?: number): Device;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListDevicesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListDevicesResponse): ListDevicesResponse.AsObject;
  static serializeBinaryToWriter(message: ListDevicesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListDevicesResponse;
  static deserializeBinaryFromReader(message: ListDevicesResponse, reader: jspb.BinaryReader): ListDevicesResponse;
}

export namespace ListDevicesResponse {
  export type AsObject = {
    devicesList: Array<Device.AsObject>,
  }
}

export class Device extends jspb.Message {
  getId(): string;
  setId(value: string): Device;

  getAuthId(): string;
  setAuthId(value: string): Device;
  hasAuthId(): boolean;
  clearAuthId(): Device;

  getAppId(): string;
  setAppId(value: string): Device;

  getOs(): string;
  setOs(value: string): Device;

  getOsVersion(): string;
  setOsVersion(value: string): Device;

  getManufacturer(): string;
  setManufacturer(value: string): Device;

  getModel(): string;
  setModel(value: string): Device;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Device.AsObject;
  static toObject(includeInstance: boolean, msg: Device): Device.AsObject;
  static serializeBinaryToWriter(message: Device, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Device;
  static deserializeBinaryFromReader(message: Device, reader: jspb.BinaryReader): Device;
}

export namespace Device {
  export type AsObject = {
    id: string,
    authId?: string,
    appId: string,
    os: string,
    osVersion: string,
    manufacturer: string,
    model: string,
  }

  export enum AuthIdCase { 
    _AUTH_ID_NOT_SET = 0,
    AUTH_ID = 2,
  }
}

export class ListKeysRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): ListKeysRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListKeysRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListKeysRequest): ListKeysRequest.AsObject;
  static serializeBinaryToWriter(message: ListKeysRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListKeysRequest;
  static deserializeBinaryFromReader(message: ListKeysRequest, reader: jspb.BinaryReader): ListKeysRequest;
}

export namespace ListKeysRequest {
  export type AsObject = {
    patientId: string,
  }
}

export class ListKeysResponse extends jspb.Message {
  getKeysList(): Array<AccessKey>;
  setKeysList(value: Array<AccessKey>): ListKeysResponse;
  clearKeysList(): ListKeysResponse;
  addKeys(value?: AccessKey, index?: number): AccessKey;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListKeysResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListKeysResponse): ListKeysResponse.AsObject;
  static serializeBinaryToWriter(message: ListKeysResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListKeysResponse;
  static deserializeBinaryFromReader(message: ListKeysResponse, reader: jspb.BinaryReader): ListKeysResponse;
}

export namespace ListKeysResponse {
  export type AsObject = {
    keysList: Array<AccessKey.AsObject>,
  }
}

export class AccessKey extends jspb.Message {
  getId(): string;
  setId(value: string): AccessKey;

  getCode(): string;
  setCode(value: string): AccessKey;

  getCreatedAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreatedAt(value?: google_protobuf_timestamp_pb.Timestamp): AccessKey;
  hasCreatedAt(): boolean;
  clearCreatedAt(): AccessKey;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AccessKey.AsObject;
  static toObject(includeInstance: boolean, msg: AccessKey): AccessKey.AsObject;
  static serializeBinaryToWriter(message: AccessKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AccessKey;
  static deserializeBinaryFromReader(message: AccessKey, reader: jspb.BinaryReader): AccessKey;
}

export namespace AccessKey {
  export type AsObject = {
    id: string,
    code: string,
    createdAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }
}

export class GenerateAccessKeyRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): GenerateAccessKeyRequest;

  getStudyId(): string;
  setStudyId(value: string): GenerateAccessKeyRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GenerateAccessKeyRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GenerateAccessKeyRequest): GenerateAccessKeyRequest.AsObject;
  static serializeBinaryToWriter(message: GenerateAccessKeyRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GenerateAccessKeyRequest;
  static deserializeBinaryFromReader(message: GenerateAccessKeyRequest, reader: jspb.BinaryReader): GenerateAccessKeyRequest;
}

export namespace GenerateAccessKeyRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
  }
}

export class GenerateAccessKeyResponse extends jspb.Message {
  getKey(): string;
  setKey(value: string): GenerateAccessKeyResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GenerateAccessKeyResponse.AsObject;
  static toObject(includeInstance: boolean, msg: GenerateAccessKeyResponse): GenerateAccessKeyResponse.AsObject;
  static serializeBinaryToWriter(message: GenerateAccessKeyResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GenerateAccessKeyResponse;
  static deserializeBinaryFromReader(message: GenerateAccessKeyResponse, reader: jspb.BinaryReader): GenerateAccessKeyResponse;
}

export namespace GenerateAccessKeyResponse {
  export type AsObject = {
    key: string,
  }
}

export class LinkAppRequest extends jspb.Message {
  getAccessCode(): string;
  setAccessCode(value: string): LinkAppRequest;

  getAppId(): string;
  setAppId(value: string): LinkAppRequest;

  getOs(): string;
  setOs(value: string): LinkAppRequest;

  getOsVersion(): string;
  setOsVersion(value: string): LinkAppRequest;

  getManufacturer(): string;
  setManufacturer(value: string): LinkAppRequest;

  getModel(): string;
  setModel(value: string): LinkAppRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LinkAppRequest.AsObject;
  static toObject(includeInstance: boolean, msg: LinkAppRequest): LinkAppRequest.AsObject;
  static serializeBinaryToWriter(message: LinkAppRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LinkAppRequest;
  static deserializeBinaryFromReader(message: LinkAppRequest, reader: jspb.BinaryReader): LinkAppRequest;
}

export namespace LinkAppRequest {
  export type AsObject = {
    accessCode: string,
    appId: string,
    os: string,
    osVersion: string,
    manufacturer: string,
    model: string,
  }
}

export class LinkAppResponse extends jspb.Message {
  getId(): string;
  setId(value: string): LinkAppResponse;

  getPatientId(): string;
  setPatientId(value: string): LinkAppResponse;

  getStudyId(): string;
  setStudyId(value: string): LinkAppResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LinkAppResponse.AsObject;
  static toObject(includeInstance: boolean, msg: LinkAppResponse): LinkAppResponse.AsObject;
  static serializeBinaryToWriter(message: LinkAppResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LinkAppResponse;
  static deserializeBinaryFromReader(message: LinkAppResponse, reader: jspb.BinaryReader): LinkAppResponse;
}

export namespace LinkAppResponse {
  export type AsObject = {
    id: string,
    patientId: string,
    studyId: string,
  }
}

