import * as grpcWeb from 'grpc-web';

import * as devices_devices_pb from '../devices/devices_pb';


export class DevicesClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: devices_devices_pb.ListDevicesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: devices_devices_pb.ListDevicesResponse) => void
  ): grpcWeb.ClientReadableStream<devices_devices_pb.ListDevicesResponse>;

  listKeys(
    request: devices_devices_pb.ListKeysRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: devices_devices_pb.ListKeysResponse) => void
  ): grpcWeb.ClientReadableStream<devices_devices_pb.ListKeysResponse>;

  generateAccessKey(
    request: devices_devices_pb.GenerateAccessKeyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: devices_devices_pb.GenerateAccessKeyResponse) => void
  ): grpcWeb.ClientReadableStream<devices_devices_pb.GenerateAccessKeyResponse>;

  linkApp(
    request: devices_devices_pb.LinkAppRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: devices_devices_pb.LinkAppResponse) => void
  ): grpcWeb.ClientReadableStream<devices_devices_pb.LinkAppResponse>;

}

export class DevicesPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: devices_devices_pb.ListDevicesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<devices_devices_pb.ListDevicesResponse>;

  listKeys(
    request: devices_devices_pb.ListKeysRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<devices_devices_pb.ListKeysResponse>;

  generateAccessKey(
    request: devices_devices_pb.GenerateAccessKeyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<devices_devices_pb.GenerateAccessKeyResponse>;

  linkApp(
    request: devices_devices_pb.LinkAppRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<devices_devices_pb.LinkAppResponse>;

}

