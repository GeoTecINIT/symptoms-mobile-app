export * from "./studies_pb";
export * from "./studies_grpc_web_pb";
//# sourceMappingURL=index.js.map