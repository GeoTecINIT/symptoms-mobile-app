import * as jspb from 'google-protobuf'



export class ListStudyPlacesRequest extends jspb.Message {
  getStudyId(): string;
  setStudyId(value: string): ListStudyPlacesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListStudyPlacesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListStudyPlacesRequest): ListStudyPlacesRequest.AsObject;
  static serializeBinaryToWriter(message: ListStudyPlacesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListStudyPlacesRequest;
  static deserializeBinaryFromReader(message: ListStudyPlacesRequest, reader: jspb.BinaryReader): ListStudyPlacesRequest;
}

export namespace ListStudyPlacesRequest {
  export type AsObject = {
    studyId: string,
  }
}

export class ListStudyPlacesResponse extends jspb.Message {
  getPlacesList(): Array<StudyPlace>;
  setPlacesList(value: Array<StudyPlace>): ListStudyPlacesResponse;
  clearPlacesList(): ListStudyPlacesResponse;
  addPlaces(value?: StudyPlace, index?: number): StudyPlace;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListStudyPlacesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListStudyPlacesResponse): ListStudyPlacesResponse.AsObject;
  static serializeBinaryToWriter(message: ListStudyPlacesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListStudyPlacesResponse;
  static deserializeBinaryFromReader(message: ListStudyPlacesResponse, reader: jspb.BinaryReader): ListStudyPlacesResponse;
}

export namespace ListStudyPlacesResponse {
  export type AsObject = {
    placesList: Array<StudyPlace.AsObject>,
  }
}

export class StudyPlace extends jspb.Message {
  getId(): string;
  setId(value: string): StudyPlace;

  getName(): string;
  setName(value: string): StudyPlace;

  getStudyId(): string;
  setStudyId(value: string): StudyPlace;

  getCategory(): string;
  setCategory(value: string): StudyPlace;
  hasCategory(): boolean;
  clearCategory(): StudyPlace;

  getCircle(): CircularGeometry | undefined;
  setCircle(value?: CircularGeometry): StudyPlace;
  hasCircle(): boolean;
  clearCircle(): StudyPlace;

  getPolygon(): PolygonalGeometry | undefined;
  setPolygon(value?: PolygonalGeometry): StudyPlace;
  hasPolygon(): boolean;
  clearPolygon(): StudyPlace;

  getGeometryCase(): StudyPlace.GeometryCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StudyPlace.AsObject;
  static toObject(includeInstance: boolean, msg: StudyPlace): StudyPlace.AsObject;
  static serializeBinaryToWriter(message: StudyPlace, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StudyPlace;
  static deserializeBinaryFromReader(message: StudyPlace, reader: jspb.BinaryReader): StudyPlace;
}

export namespace StudyPlace {
  export type AsObject = {
    id: string,
    name: string,
    studyId: string,
    category?: string,
    circle?: CircularGeometry.AsObject,
    polygon?: PolygonalGeometry.AsObject,
  }

  export enum GeometryCase { 
    GEOMETRY_NOT_SET = 0,
    CIRCLE = 5,
    POLYGON = 6,
  }

  export enum CategoryCase { 
    _CATEGORY_NOT_SET = 0,
    CATEGORY = 4,
  }
}

export class CircularGeometry extends jspb.Message {
  getCentre(): Coordinate | undefined;
  setCentre(value?: Coordinate): CircularGeometry;
  hasCentre(): boolean;
  clearCentre(): CircularGeometry;

  getRadius(): number;
  setRadius(value: number): CircularGeometry;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CircularGeometry.AsObject;
  static toObject(includeInstance: boolean, msg: CircularGeometry): CircularGeometry.AsObject;
  static serializeBinaryToWriter(message: CircularGeometry, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CircularGeometry;
  static deserializeBinaryFromReader(message: CircularGeometry, reader: jspb.BinaryReader): CircularGeometry;
}

export namespace CircularGeometry {
  export type AsObject = {
    centre?: Coordinate.AsObject,
    radius: number,
  }
}

export class PolygonalGeometry extends jspb.Message {
  getVerticesList(): Array<Coordinate>;
  setVerticesList(value: Array<Coordinate>): PolygonalGeometry;
  clearVerticesList(): PolygonalGeometry;
  addVertices(value?: Coordinate, index?: number): Coordinate;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PolygonalGeometry.AsObject;
  static toObject(includeInstance: boolean, msg: PolygonalGeometry): PolygonalGeometry.AsObject;
  static serializeBinaryToWriter(message: PolygonalGeometry, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PolygonalGeometry;
  static deserializeBinaryFromReader(message: PolygonalGeometry, reader: jspb.BinaryReader): PolygonalGeometry;
}

export namespace PolygonalGeometry {
  export type AsObject = {
    verticesList: Array<Coordinate.AsObject>,
  }
}

export class Coordinate extends jspb.Message {
  getLatitude(): number;
  setLatitude(value: number): Coordinate;

  getLongitude(): number;
  setLongitude(value: number): Coordinate;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Coordinate.AsObject;
  static toObject(includeInstance: boolean, msg: Coordinate): Coordinate.AsObject;
  static serializeBinaryToWriter(message: Coordinate, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Coordinate;
  static deserializeBinaryFromReader(message: Coordinate, reader: jspb.BinaryReader): Coordinate;
}

export namespace Coordinate {
  export type AsObject = {
    latitude: number,
    longitude: number,
  }
}

export class CreateStudyPlaceRequest extends jspb.Message {
  getName(): string;
  setName(value: string): CreateStudyPlaceRequest;

  getStudyId(): string;
  setStudyId(value: string): CreateStudyPlaceRequest;

  getCategory(): string;
  setCategory(value: string): CreateStudyPlaceRequest;
  hasCategory(): boolean;
  clearCategory(): CreateStudyPlaceRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateStudyPlaceRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateStudyPlaceRequest): CreateStudyPlaceRequest.AsObject;
  static serializeBinaryToWriter(message: CreateStudyPlaceRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateStudyPlaceRequest;
  static deserializeBinaryFromReader(message: CreateStudyPlaceRequest, reader: jspb.BinaryReader): CreateStudyPlaceRequest;
}

export namespace CreateStudyPlaceRequest {
  export type AsObject = {
    name: string,
    studyId: string,
    category?: string,
  }

  export enum CategoryCase { 
    _CATEGORY_NOT_SET = 0,
    CATEGORY = 3,
  }
}

export class CreateStudyPlaceResponse extends jspb.Message {
  getId(): string;
  setId(value: string): CreateStudyPlaceResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateStudyPlaceResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CreateStudyPlaceResponse): CreateStudyPlaceResponse.AsObject;
  static serializeBinaryToWriter(message: CreateStudyPlaceResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateStudyPlaceResponse;
  static deserializeBinaryFromReader(message: CreateStudyPlaceResponse, reader: jspb.BinaryReader): CreateStudyPlaceResponse;
}

export namespace CreateStudyPlaceResponse {
  export type AsObject = {
    id: string,
  }
}

export class UpdateStudyPlaceRequest extends jspb.Message {
  getId(): string;
  setId(value: string): UpdateStudyPlaceRequest;

  getName(): string;
  setName(value: string): UpdateStudyPlaceRequest;

  getCategory(): string;
  setCategory(value: string): UpdateStudyPlaceRequest;
  hasCategory(): boolean;
  clearCategory(): UpdateStudyPlaceRequest;

  getCircle(): CircularGeometry | undefined;
  setCircle(value?: CircularGeometry): UpdateStudyPlaceRequest;
  hasCircle(): boolean;
  clearCircle(): UpdateStudyPlaceRequest;

  getPolygon(): PolygonalGeometry | undefined;
  setPolygon(value?: PolygonalGeometry): UpdateStudyPlaceRequest;
  hasPolygon(): boolean;
  clearPolygon(): UpdateStudyPlaceRequest;

  getGeometryCase(): UpdateStudyPlaceRequest.GeometryCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateStudyPlaceRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateStudyPlaceRequest): UpdateStudyPlaceRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateStudyPlaceRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateStudyPlaceRequest;
  static deserializeBinaryFromReader(message: UpdateStudyPlaceRequest, reader: jspb.BinaryReader): UpdateStudyPlaceRequest;
}

export namespace UpdateStudyPlaceRequest {
  export type AsObject = {
    id: string,
    name: string,
    category?: string,
    circle?: CircularGeometry.AsObject,
    polygon?: PolygonalGeometry.AsObject,
  }

  export enum GeometryCase { 
    GEOMETRY_NOT_SET = 0,
    CIRCLE = 4,
    POLYGON = 5,
  }

  export enum CategoryCase { 
    _CATEGORY_NOT_SET = 0,
    CATEGORY = 3,
  }
}

export class UpdateStudyPlaceResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateStudyPlaceResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateStudyPlaceResponse): UpdateStudyPlaceResponse.AsObject;
  static serializeBinaryToWriter(message: UpdateStudyPlaceResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateStudyPlaceResponse;
  static deserializeBinaryFromReader(message: UpdateStudyPlaceResponse, reader: jspb.BinaryReader): UpdateStudyPlaceResponse;
}

export namespace UpdateStudyPlaceResponse {
  export type AsObject = {
  }
}

export class DeleteStudyPlaceRequest extends jspb.Message {
  getId(): string;
  setId(value: string): DeleteStudyPlaceRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteStudyPlaceRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteStudyPlaceRequest): DeleteStudyPlaceRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteStudyPlaceRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteStudyPlaceRequest;
  static deserializeBinaryFromReader(message: DeleteStudyPlaceRequest, reader: jspb.BinaryReader): DeleteStudyPlaceRequest;
}

export namespace DeleteStudyPlaceRequest {
  export type AsObject = {
    id: string,
  }
}

export class DeleteStudyPlaceResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteStudyPlaceResponse.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteStudyPlaceResponse): DeleteStudyPlaceResponse.AsObject;
  static serializeBinaryToWriter(message: DeleteStudyPlaceResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteStudyPlaceResponse;
  static deserializeBinaryFromReader(message: DeleteStudyPlaceResponse, reader: jspb.BinaryReader): DeleteStudyPlaceResponse;
}

export namespace DeleteStudyPlaceResponse {
  export type AsObject = {
  }
}

export class GetStudyPlaceRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetStudyPlaceRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetStudyPlaceRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetStudyPlaceRequest): GetStudyPlaceRequest.AsObject;
  static serializeBinaryToWriter(message: GetStudyPlaceRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetStudyPlaceRequest;
  static deserializeBinaryFromReader(message: GetStudyPlaceRequest, reader: jspb.BinaryReader): GetStudyPlaceRequest;
}

export namespace GetStudyPlaceRequest {
  export type AsObject = {
    id: string,
  }
}

export class CopyAllStudyPlacesRequest extends jspb.Message {
  getSourceStudyId(): string;
  setSourceStudyId(value: string): CopyAllStudyPlacesRequest;

  getTargetPlaceId(): string;
  setTargetPlaceId(value: string): CopyAllStudyPlacesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CopyAllStudyPlacesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CopyAllStudyPlacesRequest): CopyAllStudyPlacesRequest.AsObject;
  static serializeBinaryToWriter(message: CopyAllStudyPlacesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CopyAllStudyPlacesRequest;
  static deserializeBinaryFromReader(message: CopyAllStudyPlacesRequest, reader: jspb.BinaryReader): CopyAllStudyPlacesRequest;
}

export namespace CopyAllStudyPlacesRequest {
  export type AsObject = {
    sourceStudyId: string,
    targetPlaceId: string,
  }
}

export class CopyAllStudyPlacesResponse extends jspb.Message {
  getOriginalIdsList(): Array<string>;
  setOriginalIdsList(value: Array<string>): CopyAllStudyPlacesResponse;
  clearOriginalIdsList(): CopyAllStudyPlacesResponse;
  addOriginalIds(value: string, index?: number): CopyAllStudyPlacesResponse;

  getNewIdsList(): Array<string>;
  setNewIdsList(value: Array<string>): CopyAllStudyPlacesResponse;
  clearNewIdsList(): CopyAllStudyPlacesResponse;
  addNewIds(value: string, index?: number): CopyAllStudyPlacesResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CopyAllStudyPlacesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CopyAllStudyPlacesResponse): CopyAllStudyPlacesResponse.AsObject;
  static serializeBinaryToWriter(message: CopyAllStudyPlacesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CopyAllStudyPlacesResponse;
  static deserializeBinaryFromReader(message: CopyAllStudyPlacesResponse, reader: jspb.BinaryReader): CopyAllStudyPlacesResponse;
}

export namespace CopyAllStudyPlacesResponse {
  export type AsObject = {
    originalIdsList: Array<string>,
    newIdsList: Array<string>,
  }
}

export class ListPatientStudyPlacesRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): ListPatientStudyPlacesRequest;

  getStudyId(): string;
  setStudyId(value: string): ListPatientStudyPlacesRequest;

  getActiveOnly(): boolean;
  setActiveOnly(value: boolean): ListPatientStudyPlacesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListPatientStudyPlacesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListPatientStudyPlacesRequest): ListPatientStudyPlacesRequest.AsObject;
  static serializeBinaryToWriter(message: ListPatientStudyPlacesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListPatientStudyPlacesRequest;
  static deserializeBinaryFromReader(message: ListPatientStudyPlacesRequest, reader: jspb.BinaryReader): ListPatientStudyPlacesRequest;
}

export namespace ListPatientStudyPlacesRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    activeOnly: boolean,
  }
}

export class ListPatientStudyPlacesResponse extends jspb.Message {
  getPlacesList(): Array<PatientStudyPlace>;
  setPlacesList(value: Array<PatientStudyPlace>): ListPatientStudyPlacesResponse;
  clearPlacesList(): ListPatientStudyPlacesResponse;
  addPlaces(value?: PatientStudyPlace, index?: number): PatientStudyPlace;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListPatientStudyPlacesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListPatientStudyPlacesResponse): ListPatientStudyPlacesResponse.AsObject;
  static serializeBinaryToWriter(message: ListPatientStudyPlacesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListPatientStudyPlacesResponse;
  static deserializeBinaryFromReader(message: ListPatientStudyPlacesResponse, reader: jspb.BinaryReader): ListPatientStudyPlacesResponse;
}

export namespace ListPatientStudyPlacesResponse {
  export type AsObject = {
    placesList: Array<PatientStudyPlace.AsObject>,
  }
}

export class PatientStudyPlace extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): PatientStudyPlace;

  getStudyId(): string;
  setStudyId(value: string): PatientStudyPlace;

  getComplexity(): number;
  setComplexity(value: number): PatientStudyPlace;

  getPlace(): StudyPlace | undefined;
  setPlace(value?: StudyPlace): PatientStudyPlace;
  hasPlace(): boolean;
  clearPlace(): PatientStudyPlace;

  getActiveOnly(): boolean;
  setActiveOnly(value: boolean): PatientStudyPlace;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PatientStudyPlace.AsObject;
  static toObject(includeInstance: boolean, msg: PatientStudyPlace): PatientStudyPlace.AsObject;
  static serializeBinaryToWriter(message: PatientStudyPlace, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PatientStudyPlace;
  static deserializeBinaryFromReader(message: PatientStudyPlace, reader: jspb.BinaryReader): PatientStudyPlace;
}

export namespace PatientStudyPlace {
  export type AsObject = {
    patientId: string,
    studyId: string,
    complexity: number,
    place?: StudyPlace.AsObject,
    activeOnly: boolean,
  }
}

export class AddPatientStudyPlaceRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): AddPatientStudyPlaceRequest;

  getStudyId(): string;
  setStudyId(value: string): AddPatientStudyPlaceRequest;

  getPlaceId(): string;
  setPlaceId(value: string): AddPatientStudyPlaceRequest;

  getComplexity(): number;
  setComplexity(value: number): AddPatientStudyPlaceRequest;

  getActive(): boolean;
  setActive(value: boolean): AddPatientStudyPlaceRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AddPatientStudyPlaceRequest.AsObject;
  static toObject(includeInstance: boolean, msg: AddPatientStudyPlaceRequest): AddPatientStudyPlaceRequest.AsObject;
  static serializeBinaryToWriter(message: AddPatientStudyPlaceRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AddPatientStudyPlaceRequest;
  static deserializeBinaryFromReader(message: AddPatientStudyPlaceRequest, reader: jspb.BinaryReader): AddPatientStudyPlaceRequest;
}

export namespace AddPatientStudyPlaceRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    placeId: string,
    complexity: number,
    active: boolean,
  }
}

export class UpdatePatientStudyPlaceRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): UpdatePatientStudyPlaceRequest;

  getStudyId(): string;
  setStudyId(value: string): UpdatePatientStudyPlaceRequest;

  getPlaceId(): string;
  setPlaceId(value: string): UpdatePatientStudyPlaceRequest;

  getComplexity(): number;
  setComplexity(value: number): UpdatePatientStudyPlaceRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdatePatientStudyPlaceRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdatePatientStudyPlaceRequest): UpdatePatientStudyPlaceRequest.AsObject;
  static serializeBinaryToWriter(message: UpdatePatientStudyPlaceRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdatePatientStudyPlaceRequest;
  static deserializeBinaryFromReader(message: UpdatePatientStudyPlaceRequest, reader: jspb.BinaryReader): UpdatePatientStudyPlaceRequest;
}

export namespace UpdatePatientStudyPlaceRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    placeId: string,
    complexity: number,
  }
}

export class UpdatePatientStudyPlaceResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdatePatientStudyPlaceResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdatePatientStudyPlaceResponse): UpdatePatientStudyPlaceResponse.AsObject;
  static serializeBinaryToWriter(message: UpdatePatientStudyPlaceResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdatePatientStudyPlaceResponse;
  static deserializeBinaryFromReader(message: UpdatePatientStudyPlaceResponse, reader: jspb.BinaryReader): UpdatePatientStudyPlaceResponse;
}

export namespace UpdatePatientStudyPlaceResponse {
  export type AsObject = {
  }
}

export class RemovePatientStudyPlaceRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): RemovePatientStudyPlaceRequest;

  getStudyId(): string;
  setStudyId(value: string): RemovePatientStudyPlaceRequest;

  getPlaceId(): string;
  setPlaceId(value: string): RemovePatientStudyPlaceRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RemovePatientStudyPlaceRequest.AsObject;
  static toObject(includeInstance: boolean, msg: RemovePatientStudyPlaceRequest): RemovePatientStudyPlaceRequest.AsObject;
  static serializeBinaryToWriter(message: RemovePatientStudyPlaceRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RemovePatientStudyPlaceRequest;
  static deserializeBinaryFromReader(message: RemovePatientStudyPlaceRequest, reader: jspb.BinaryReader): RemovePatientStudyPlaceRequest;
}

export namespace RemovePatientStudyPlaceRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    placeId: string,
  }
}

export class ActivatePatientStudyPlacesRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): ActivatePatientStudyPlacesRequest;

  getStudyId(): string;
  setStudyId(value: string): ActivatePatientStudyPlacesRequest;

  getPlaceIdsList(): Array<string>;
  setPlaceIdsList(value: Array<string>): ActivatePatientStudyPlacesRequest;
  clearPlaceIdsList(): ActivatePatientStudyPlacesRequest;
  addPlaceIds(value: string, index?: number): ActivatePatientStudyPlacesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ActivatePatientStudyPlacesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ActivatePatientStudyPlacesRequest): ActivatePatientStudyPlacesRequest.AsObject;
  static serializeBinaryToWriter(message: ActivatePatientStudyPlacesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ActivatePatientStudyPlacesRequest;
  static deserializeBinaryFromReader(message: ActivatePatientStudyPlacesRequest, reader: jspb.BinaryReader): ActivatePatientStudyPlacesRequest;
}

export namespace ActivatePatientStudyPlacesRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    placeIdsList: Array<string>,
  }
}

export class ActivatePatientStudyPlacesResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ActivatePatientStudyPlacesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ActivatePatientStudyPlacesResponse): ActivatePatientStudyPlacesResponse.AsObject;
  static serializeBinaryToWriter(message: ActivatePatientStudyPlacesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ActivatePatientStudyPlacesResponse;
  static deserializeBinaryFromReader(message: ActivatePatientStudyPlacesResponse, reader: jspb.BinaryReader): ActivatePatientStudyPlacesResponse;
}

export namespace ActivatePatientStudyPlacesResponse {
  export type AsObject = {
  }
}

