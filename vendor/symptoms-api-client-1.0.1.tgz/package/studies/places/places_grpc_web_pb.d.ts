import * as grpcWeb from 'grpc-web';

import * as studies_places_places_pb from '../../studies/places/places_pb';


export class StudyPlacesClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: studies_places_places_pb.ListStudyPlacesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.ListStudyPlacesResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.ListStudyPlacesResponse>;

  create(
    request: studies_places_places_pb.CreateStudyPlaceRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.CreateStudyPlaceResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.CreateStudyPlaceResponse>;

  update(
    request: studies_places_places_pb.UpdateStudyPlaceRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.UpdateStudyPlaceResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.UpdateStudyPlaceResponse>;

  delete(
    request: studies_places_places_pb.DeleteStudyPlaceRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.DeleteStudyPlaceResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.DeleteStudyPlaceResponse>;

  get(
    request: studies_places_places_pb.GetStudyPlaceRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.StudyPlace) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.StudyPlace>;

  copyAll(
    request: studies_places_places_pb.CopyAllStudyPlacesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.CopyAllStudyPlacesResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.CopyAllStudyPlacesResponse>;

}

export class PatientStudyPlacesClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: studies_places_places_pb.ListPatientStudyPlacesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.ListPatientStudyPlacesResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.ListPatientStudyPlacesResponse>;

  add(
    request: studies_places_places_pb.AddPatientStudyPlaceRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.UpdatePatientStudyPlaceResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.UpdatePatientStudyPlaceResponse>;

  update(
    request: studies_places_places_pb.UpdatePatientStudyPlaceRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.UpdatePatientStudyPlaceResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.UpdatePatientStudyPlaceResponse>;

  remove(
    request: studies_places_places_pb.RemovePatientStudyPlaceRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.UpdatePatientStudyPlaceResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.UpdatePatientStudyPlaceResponse>;

  activate(
    request: studies_places_places_pb.ActivatePatientStudyPlacesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_places_places_pb.ActivatePatientStudyPlacesResponse) => void
  ): grpcWeb.ClientReadableStream<studies_places_places_pb.ActivatePatientStudyPlacesResponse>;

}

export class StudyPlacesPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: studies_places_places_pb.ListStudyPlacesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.ListStudyPlacesResponse>;

  create(
    request: studies_places_places_pb.CreateStudyPlaceRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.CreateStudyPlaceResponse>;

  update(
    request: studies_places_places_pb.UpdateStudyPlaceRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.UpdateStudyPlaceResponse>;

  delete(
    request: studies_places_places_pb.DeleteStudyPlaceRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.DeleteStudyPlaceResponse>;

  get(
    request: studies_places_places_pb.GetStudyPlaceRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.StudyPlace>;

  copyAll(
    request: studies_places_places_pb.CopyAllStudyPlacesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.CopyAllStudyPlacesResponse>;

}

export class PatientStudyPlacesPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: studies_places_places_pb.ListPatientStudyPlacesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.ListPatientStudyPlacesResponse>;

  add(
    request: studies_places_places_pb.AddPatientStudyPlaceRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.UpdatePatientStudyPlaceResponse>;

  update(
    request: studies_places_places_pb.UpdatePatientStudyPlaceRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.UpdatePatientStudyPlaceResponse>;

  remove(
    request: studies_places_places_pb.RemovePatientStudyPlaceRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.UpdatePatientStudyPlaceResponse>;

  activate(
    request: studies_places_places_pb.ActivatePatientStudyPlacesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_places_places_pb.ActivatePatientStudyPlacesResponse>;

}

