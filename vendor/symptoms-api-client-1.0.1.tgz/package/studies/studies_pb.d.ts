import * as jspb from 'google-protobuf'

import * as google_protobuf_timestamp_pb from 'google-protobuf/google/protobuf/timestamp_pb';


export class ListStudiesRequest extends jspb.Message {
  getCentreId(): string;
  setCentreId(value: string): ListStudiesRequest;
  hasCentreId(): boolean;
  clearCentreId(): ListStudiesRequest;

  getCreatorId(): string;
  setCreatorId(value: string): ListStudiesRequest;
  hasCreatorId(): boolean;
  clearCreatorId(): ListStudiesRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListStudiesRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListStudiesRequest): ListStudiesRequest.AsObject;
  static serializeBinaryToWriter(message: ListStudiesRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListStudiesRequest;
  static deserializeBinaryFromReader(message: ListStudiesRequest, reader: jspb.BinaryReader): ListStudiesRequest;
}

export namespace ListStudiesRequest {
  export type AsObject = {
    centreId?: string,
    creatorId?: string,
  }

  export enum CentreIdCase { 
    _CENTRE_ID_NOT_SET = 0,
    CENTRE_ID = 1,
  }

  export enum CreatorIdCase { 
    _CREATOR_ID_NOT_SET = 0,
    CREATOR_ID = 2,
  }
}

export class ListStudiesResponse extends jspb.Message {
  getStudiesList(): Array<Study>;
  setStudiesList(value: Array<Study>): ListStudiesResponse;
  clearStudiesList(): ListStudiesResponse;
  addStudies(value?: Study, index?: number): Study;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListStudiesResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListStudiesResponse): ListStudiesResponse.AsObject;
  static serializeBinaryToWriter(message: ListStudiesResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListStudiesResponse;
  static deserializeBinaryFromReader(message: ListStudiesResponse, reader: jspb.BinaryReader): ListStudiesResponse;
}

export namespace ListStudiesResponse {
  export type AsObject = {
    studiesList: Array<Study.AsObject>,
  }
}

export class Study extends jspb.Message {
  getId(): string;
  setId(value: string): Study;

  getName(): string;
  setName(value: string): Study;

  getType(): Study.Type;
  setType(value: Study.Type): Study;

  getCentreId(): string;
  setCentreId(value: string): Study;

  getCreatorId(): string;
  setCreatorId(value: string): Study;

  getCreatedAt(): google_protobuf_timestamp_pb.Timestamp | undefined;
  setCreatedAt(value?: google_protobuf_timestamp_pb.Timestamp): Study;
  hasCreatedAt(): boolean;
  clearCreatedAt(): Study;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Study.AsObject;
  static toObject(includeInstance: boolean, msg: Study): Study.AsObject;
  static serializeBinaryToWriter(message: Study, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Study;
  static deserializeBinaryFromReader(message: Study, reader: jspb.BinaryReader): Study;
}

export namespace Study {
  export type AsObject = {
    id: string,
    name: string,
    type: Study.Type,
    centreId: string,
    creatorId: string,
    createdAt?: google_protobuf_timestamp_pb.Timestamp.AsObject,
  }

  export enum Type { 
    INDIVIDUAL = 0,
    GROUP = 1,
  }
}

export class CreateStudyRequest extends jspb.Message {
  getName(): string;
  setName(value: string): CreateStudyRequest;

  getType(): Study.Type;
  setType(value: Study.Type): CreateStudyRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateStudyRequest.AsObject;
  static toObject(includeInstance: boolean, msg: CreateStudyRequest): CreateStudyRequest.AsObject;
  static serializeBinaryToWriter(message: CreateStudyRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateStudyRequest;
  static deserializeBinaryFromReader(message: CreateStudyRequest, reader: jspb.BinaryReader): CreateStudyRequest;
}

export namespace CreateStudyRequest {
  export type AsObject = {
    name: string,
    type: Study.Type,
  }
}

export class CreateStudyResponse extends jspb.Message {
  getId(): string;
  setId(value: string): CreateStudyResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CreateStudyResponse.AsObject;
  static toObject(includeInstance: boolean, msg: CreateStudyResponse): CreateStudyResponse.AsObject;
  static serializeBinaryToWriter(message: CreateStudyResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CreateStudyResponse;
  static deserializeBinaryFromReader(message: CreateStudyResponse, reader: jspb.BinaryReader): CreateStudyResponse;
}

export namespace CreateStudyResponse {
  export type AsObject = {
    id: string,
  }
}

export class DuplicateStudyRequest extends jspb.Message {
  getSourceId(): string;
  setSourceId(value: string): DuplicateStudyRequest;

  getNewName(): string;
  setNewName(value: string): DuplicateStudyRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DuplicateStudyRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DuplicateStudyRequest): DuplicateStudyRequest.AsObject;
  static serializeBinaryToWriter(message: DuplicateStudyRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DuplicateStudyRequest;
  static deserializeBinaryFromReader(message: DuplicateStudyRequest, reader: jspb.BinaryReader): DuplicateStudyRequest;
}

export namespace DuplicateStudyRequest {
  export type AsObject = {
    sourceId: string,
    newName: string,
  }
}

export class UpdateStudyRequest extends jspb.Message {
  getId(): string;
  setId(value: string): UpdateStudyRequest;

  getName(): string;
  setName(value: string): UpdateStudyRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateStudyRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateStudyRequest): UpdateStudyRequest.AsObject;
  static serializeBinaryToWriter(message: UpdateStudyRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateStudyRequest;
  static deserializeBinaryFromReader(message: UpdateStudyRequest, reader: jspb.BinaryReader): UpdateStudyRequest;
}

export namespace UpdateStudyRequest {
  export type AsObject = {
    id: string,
    name: string,
  }
}

export class UpdateStudyResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateStudyResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateStudyResponse): UpdateStudyResponse.AsObject;
  static serializeBinaryToWriter(message: UpdateStudyResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateStudyResponse;
  static deserializeBinaryFromReader(message: UpdateStudyResponse, reader: jspb.BinaryReader): UpdateStudyResponse;
}

export namespace UpdateStudyResponse {
  export type AsObject = {
  }
}

export class DeleteStudyRequest extends jspb.Message {
  getId(): string;
  setId(value: string): DeleteStudyRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteStudyRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteStudyRequest): DeleteStudyRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteStudyRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteStudyRequest;
  static deserializeBinaryFromReader(message: DeleteStudyRequest, reader: jspb.BinaryReader): DeleteStudyRequest;
}

export namespace DeleteStudyRequest {
  export type AsObject = {
    id: string,
  }
}

export class DeleteStudyResponse extends jspb.Message {
  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteStudyResponse.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteStudyResponse): DeleteStudyResponse.AsObject;
  static serializeBinaryToWriter(message: DeleteStudyResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteStudyResponse;
  static deserializeBinaryFromReader(message: DeleteStudyResponse, reader: jspb.BinaryReader): DeleteStudyResponse;
}

export namespace DeleteStudyResponse {
  export type AsObject = {
  }
}

export class GetStudyRequest extends jspb.Message {
  getId(): string;
  setId(value: string): GetStudyRequest;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetStudyRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetStudyRequest): GetStudyRequest.AsObject;
  static serializeBinaryToWriter(message: GetStudyRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetStudyRequest;
  static deserializeBinaryFromReader(message: GetStudyRequest, reader: jspb.BinaryReader): GetStudyRequest;
}

export namespace GetStudyRequest {
  export type AsObject = {
    id: string,
  }
}

