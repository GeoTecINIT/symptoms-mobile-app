import * as grpcWeb from 'grpc-web';

import * as studies_studies_pb from '../studies/studies_pb';


export class StudiesClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: studies_studies_pb.ListStudiesRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_studies_pb.ListStudiesResponse) => void
  ): grpcWeb.ClientReadableStream<studies_studies_pb.ListStudiesResponse>;

  create(
    request: studies_studies_pb.CreateStudyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_studies_pb.CreateStudyResponse) => void
  ): grpcWeb.ClientReadableStream<studies_studies_pb.CreateStudyResponse>;

  duplicate(
    request: studies_studies_pb.DuplicateStudyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_studies_pb.CreateStudyResponse) => void
  ): grpcWeb.ClientReadableStream<studies_studies_pb.CreateStudyResponse>;

  update(
    request: studies_studies_pb.UpdateStudyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_studies_pb.UpdateStudyResponse) => void
  ): grpcWeb.ClientReadableStream<studies_studies_pb.UpdateStudyResponse>;

  delete(
    request: studies_studies_pb.DeleteStudyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_studies_pb.DeleteStudyResponse) => void
  ): grpcWeb.ClientReadableStream<studies_studies_pb.DeleteStudyResponse>;

  get(
    request: studies_studies_pb.GetStudyRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: studies_studies_pb.Study) => void
  ): grpcWeb.ClientReadableStream<studies_studies_pb.Study>;

}

export class StudiesPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  list(
    request: studies_studies_pb.ListStudiesRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_studies_pb.ListStudiesResponse>;

  create(
    request: studies_studies_pb.CreateStudyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_studies_pb.CreateStudyResponse>;

  duplicate(
    request: studies_studies_pb.DuplicateStudyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_studies_pb.CreateStudyResponse>;

  update(
    request: studies_studies_pb.UpdateStudyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_studies_pb.UpdateStudyResponse>;

  delete(
    request: studies_studies_pb.DeleteStudyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_studies_pb.DeleteStudyResponse>;

  get(
    request: studies_studies_pb.GetStudyRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<studies_studies_pb.Study>;

}

