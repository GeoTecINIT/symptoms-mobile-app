import * as jspb from 'google-protobuf'

import * as records_records_pb from '../records/records_pb';
import * as traces_traces_pb from '../traces/traces_pb';


export class UploadRecordsRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): UploadRecordsRequest;

  getStudyId(): string;
  setStudyId(value: string): UploadRecordsRequest;

  getSource(): records_records_pb.RecordSource;
  setSource(value: records_records_pb.RecordSource): UploadRecordsRequest;

  getRecordsList(): Array<records_records_pb.Record>;
  setRecordsList(value: Array<records_records_pb.Record>): UploadRecordsRequest;
  clearRecordsList(): UploadRecordsRequest;
  addRecords(value?: records_records_pb.Record, index?: number): records_records_pb.Record;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UploadRecordsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UploadRecordsRequest): UploadRecordsRequest.AsObject;
  static serializeBinaryToWriter(message: UploadRecordsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UploadRecordsRequest;
  static deserializeBinaryFromReader(message: UploadRecordsRequest, reader: jspb.BinaryReader): UploadRecordsRequest;
}

export namespace UploadRecordsRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    source: records_records_pb.RecordSource,
    recordsList: Array<records_records_pb.Record.AsObject>,
  }
}

export class UploadRecordsResponse extends jspb.Message {
  getIdsList(): Array<string>;
  setIdsList(value: Array<string>): UploadRecordsResponse;
  clearIdsList(): UploadRecordsResponse;
  addIds(value: string, index?: number): UploadRecordsResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UploadRecordsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UploadRecordsResponse): UploadRecordsResponse.AsObject;
  static serializeBinaryToWriter(message: UploadRecordsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UploadRecordsResponse;
  static deserializeBinaryFromReader(message: UploadRecordsResponse, reader: jspb.BinaryReader): UploadRecordsResponse;
}

export namespace UploadRecordsResponse {
  export type AsObject = {
    idsList: Array<string>,
  }
}

export class UploadTelemetryRequest extends jspb.Message {
  getPatientId(): string;
  setPatientId(value: string): UploadTelemetryRequest;

  getStudyId(): string;
  setStudyId(value: string): UploadTelemetryRequest;

  getTracesList(): Array<traces_traces_pb.Trace>;
  setTracesList(value: Array<traces_traces_pb.Trace>): UploadTelemetryRequest;
  clearTracesList(): UploadTelemetryRequest;
  addTraces(value?: traces_traces_pb.Trace, index?: number): traces_traces_pb.Trace;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UploadTelemetryRequest.AsObject;
  static toObject(includeInstance: boolean, msg: UploadTelemetryRequest): UploadTelemetryRequest.AsObject;
  static serializeBinaryToWriter(message: UploadTelemetryRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UploadTelemetryRequest;
  static deserializeBinaryFromReader(message: UploadTelemetryRequest, reader: jspb.BinaryReader): UploadTelemetryRequest;
}

export namespace UploadTelemetryRequest {
  export type AsObject = {
    patientId: string,
    studyId: string,
    tracesList: Array<traces_traces_pb.Trace.AsObject>,
  }
}

export class UploadTelemetryResponse extends jspb.Message {
  getIdsList(): Array<string>;
  setIdsList(value: Array<string>): UploadTelemetryResponse;
  clearIdsList(): UploadTelemetryResponse;
  addIds(value: string, index?: number): UploadTelemetryResponse;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UploadTelemetryResponse.AsObject;
  static toObject(includeInstance: boolean, msg: UploadTelemetryResponse): UploadTelemetryResponse.AsObject;
  static serializeBinaryToWriter(message: UploadTelemetryResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UploadTelemetryResponse;
  static deserializeBinaryFromReader(message: UploadTelemetryResponse, reader: jspb.BinaryReader): UploadTelemetryResponse;
}

export namespace UploadTelemetryResponse {
  export type AsObject = {
    idsList: Array<string>,
  }
}

