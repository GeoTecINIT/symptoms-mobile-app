import * as grpcWeb from 'grpc-web';

import * as uploads_uploads_pb from '../uploads/uploads_pb';


export class UploadsClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  uploadRecords(
    request: uploads_uploads_pb.UploadRecordsRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: uploads_uploads_pb.UploadRecordsResponse) => void
  ): grpcWeb.ClientReadableStream<uploads_uploads_pb.UploadRecordsResponse>;

  uploadTelemetry(
    request: uploads_uploads_pb.UploadTelemetryRequest,
    metadata: grpcWeb.Metadata | undefined,
    callback: (err: grpcWeb.RpcError,
               response: uploads_uploads_pb.UploadTelemetryResponse) => void
  ): grpcWeb.ClientReadableStream<uploads_uploads_pb.UploadTelemetryResponse>;

}

export class UploadsPromiseClient {
  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: any; });

  uploadRecords(
    request: uploads_uploads_pb.UploadRecordsRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<uploads_uploads_pb.UploadRecordsResponse>;

  uploadTelemetry(
    request: uploads_uploads_pb.UploadTelemetryRequest,
    metadata?: grpcWeb.Metadata
  ): Promise<uploads_uploads_pb.UploadTelemetryResponse>;

}

