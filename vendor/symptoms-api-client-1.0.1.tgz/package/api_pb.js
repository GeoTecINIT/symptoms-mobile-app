// source: api.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {missingRequire} reports error on implicit type usages.
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!
/* eslint-disable */
// @ts-nocheck

var jspb = require('google-protobuf');
var goog = jspb;
var global =
    (typeof globalThis !== 'undefined' && globalThis) ||
    (typeof window !== 'undefined' && window) ||
    (typeof global !== 'undefined' && global) ||
    (typeof self !== 'undefined' && self) ||
    (function () { return this; }).call(null) ||
    Function('return this')();

var centres_centres_pb = require('./centres/centres_pb.js');
goog.object.extend(proto, centres_centres_pb);
var therapists_therapists_pb = require('./therapists/therapists_pb.js');
goog.object.extend(proto, therapists_therapists_pb);
var studies_studies_pb = require('./studies/studies_pb.js');
goog.object.extend(proto, studies_studies_pb);
var studies_places_places_pb = require('./studies/places/places_pb.js');
goog.object.extend(proto, studies_places_places_pb);
var patients_patients_pb = require('./patients/patients_pb.js');
goog.object.extend(proto, patients_patients_pb);
var configs_configs_pb = require('./configs/configs_pb.js');
goog.object.extend(proto, configs_configs_pb);
var configs_contents_contents_pb = require('./configs/contents/contents_pb.js');
goog.object.extend(proto, configs_contents_contents_pb);
var configs_notifications_notifications_pb = require('./configs/notifications/notifications_pb.js');
goog.object.extend(proto, configs_notifications_notifications_pb);
var configs_workflows_workflows_pb = require('./configs/workflows/workflows_pb.js');
goog.object.extend(proto, configs_workflows_workflows_pb);
var devices_devices_pb = require('./devices/devices_pb.js');
goog.object.extend(proto, devices_devices_pb);
var uploads_uploads_pb = require('./uploads/uploads_pb.js');
goog.object.extend(proto, uploads_uploads_pb);
var queries_queries_pb = require('./queries/queries_pb.js');
goog.object.extend(proto, queries_queries_pb);
