# NativeScript AutoStarter

This plugin allows to show the auto-start permission screen for several manufacturers of Android devices.
This wouldn't be possible without the [AutoStarter](https://github.com/judemanutd/AutoStarter) project developed by
[Jude Fernandes](https://github.com/judemanutd).

The plugin shows a confirmation dialog where the developer can explain why the auto-start permissions are required for
the correct operation of the application. The dialog offers the user three options:

- Positive option (i.e., OK button): the auto-start permissions screen is opened for the user to grant the required permissions.
- Negative option (i.e., Cancel button): the dialog is closed and the auto-start permissions screen is not shown. The dialog can be prompted again after a configurable amount of time (not automatically, but executing the plugin workflow again).
- Don't show again button: it is shown from the second time the dialog is shown to the user. If the user selects this option, the dialog will not be shown again.

All texts in the dialog are customizable via resource strings.

## Availability
This plugin **ONLY** works for Android devices from some manufacturers (i.e., Xiaomi, Huawei, Honor, etc). Nevertheless, the plugin
could not work for some models of the supported manufacturers.

## Installation

## Initialization

First, include in your `strings.xml` file (`App_Resources -> Android -> src -> main -> res -> values`) the following strings:

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
  <!--> Other strings <-->
  <string name="autostarter_dialog_title">"Autostart permissions"</string>
  <string name="autostarter_dialog_message">"The app could not work as expected if you don\'t grant the autostart permissions. Tap OK to go to the autostart screen options and to grant the required permissions to this app."</string>
  <string name="autostarter_dialog_okButtonText">"Ok"</string>
  <string name="autostarter_dialog_cancelButtonText">"Cancel"</string>
  <string name="autostarter_dialog_dontShowAgainButtonText">"Don\'t show again"</string>
  <!--> Other strings <-->
</resources>
```
Of course, you can customize the text of every string.

Alternatively, if you are using internationalization (i18n) using [@nativescript/localize](https://docs.nativescript.org/plugins/localize.html) you can place
the previous strings in your `i18n/*.json` files. For example:

```json
// en.default.json
{
  "app.name": "Your app name",
  "title_activity_kimera": "Your app name",
  "autostarter_dialog_title": "Autostart permissions",
  "autostarter_dialog_message": "The app could not work as expected if you don't grant the autostart permissions. Tap OK to go to the autostart screen options and to grant the required permissions to this app.",
  "autostarter_dialog_okButtonText": "OK",
  "autostarter_dialog_cancelButtonText": "Cancel",
  "autostarter_dialog_dontShowAgainButtonText": "Don't show again"
}
```
Make sure that strings in `App_Resources -> Android -> src -> main -> res -> values[-lang]` are properly generated

Next, you have to initialize the plugin with the configuration options (See [ConfigParams](#ConfigParams) and [RetryFrequency](#RetryFrequency)).

```ts
// app.ts

import { autoStarter } from "nativescript-autostarter";

autoStarter.init({
    retryFrequency: { // We set the maximum retry frequency at 1 day.
        value: 1,
        unit: "days",
    }
});
```

## Usage

```ts
// home-page.ts

import { autoStarter } from "nativescript-autostarter";

...

async autoStarter() {
    const autoStarterManager = autoStarter.getManager();
    const available = autoStarterManager.canShowAutoStartDialogRequest()
    console.log(`Can show dialog request: ${available}`);

    if (available) {
        const dialogResponse = await autoStarterManager.showAutoStartDialogRequest();
        console.log(`Dialog response: ${dialogResponse}`);
    }
}
```

## API

### autoStarter
Entry point. A singleton instance that can be used to initialize the plugin and to obtain the `AutoStarterManager`.
  
| Methods | Return type | Description |
| --- | --- | --- |
| `init(configParams?: ConfigParams)` | `void` | Initializes the plugin with the configuration parameters. |
| `getManager()` | `AutoStarterManager` | Allows to obtain the object which will be used to check the existence of the auto-start permissions and to launch its configuration screen. |

### ConfigParams
Plugin configuration parameters.

| Field | Type | Description |
| --- | --- | --- |
| `retryFrequency?` | `RetryFrequency` | Indicates the maximum frequency at which the auto-starter confirmation dialog will be shown. For example, a frequency of 1 day ensures that the user will never be prompted with the confirmation dialog in less than 24 hours since last time the dialog was prompted.  | 

### RetryFrequency

| Field | Type | Description |
| --- | --- | --- |
| `value` | `number` | Quantity of units |
| `unit` | `string` | One of these time units: "minutes", "hours", "days" |

### AutoStarterManager

| Methods | Return type | Description |
| --- | --- | --- |
| `canShowAutoStartDialogRequest()` | `boolean` | Returns `true` if the manufacturer is supported and the auto-start permissions screen can be opened. Always returns `false` in iOS. |
| `showAutoStartDialogRequest()` | `Promise<AutoStarterDialogResponse>` | Shows a dialog explaining why the auto-start permissions are needed. The user can choose to open or not the auto-start permissions screen. The user can also choose to not be prompted again with this dialog. Return values are: OK, CANCELLED and DONT_SHOW_AGAIN. Always returns `undefined` for iOS. |
| `restartAutoStarterState()` | `void` | Clears plugin's state (i.e., last time dialog was shown, etc.) |
    
## License

MIT License Copyright (c) 2021 Miguel Matey.

### AutoStarter by *judemanutd*

MIT License Copyright (c) 2018 Jude Fernandes.
