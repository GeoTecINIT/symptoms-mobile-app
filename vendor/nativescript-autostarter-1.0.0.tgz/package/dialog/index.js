export { AutoStarterDialogResponse } from '../internal/dialog';
//# sourceMappingURL=index.js.map