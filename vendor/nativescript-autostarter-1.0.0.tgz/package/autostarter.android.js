import { Common } from './autostarter.common';
export class Autostarter extends Common {
}
export const autoStarter = new Autostarter();
//# sourceMappingURL=autostarter.android.js.map