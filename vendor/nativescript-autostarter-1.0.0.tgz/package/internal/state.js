import { getBoolean, setBoolean, setString, getString, remove, flush } from '@nativescript/core/application-settings';
const SCREEN_ALREADY_SHOWN = "screen_already_shown";
const DIALOG_LAST_TIME_SHOWN = "dialog_last_time_shown";
const SHOW_AGAIN = "show_again";
const RETRY_FREQUENCY = "retry_frequency";
export class AutoStarterState {
    get screenAlreadyShown() {
        if (!this._screenAlreadyShown) {
            this._screenAlreadyShown = getBoolean(SCREEN_ALREADY_SHOWN, false);
        }
        return this._screenAlreadyShown;
    }
    set screenAlreadyShown(shown) {
        this._screenAlreadyShown = shown;
        setBoolean(SCREEN_ALREADY_SHOWN, shown);
        flush();
    }
    get dialogLastTimeShown() {
        if (!this._dialogLastTimeShown) {
            this._dialogLastTimeShown = this.getNumber(DIALOG_LAST_TIME_SHOWN);
        }
        return this._dialogLastTimeShown;
    }
    set dialogLastTimeShown(timestamp) {
        this._dialogLastTimeShown = timestamp;
        this.setNumber(DIALOG_LAST_TIME_SHOWN, timestamp);
        flush();
    }
    get showAgain() {
        if (!this._showAgain) {
            this._showAgain = getBoolean(SHOW_AGAIN, true);
        }
        return this._showAgain;
    }
    set showAgain(show) {
        this._showAgain = show;
        setBoolean(SHOW_AGAIN, show);
        flush();
    }
    get retryFrequency() {
        if (!this._retryFrequency) {
            this._retryFrequency = this.getNumber(RETRY_FREQUENCY);
        }
        return this._retryFrequency;
    }
    set retryFrequency(frequency) {
        this._retryFrequency = frequency;
        this.setNumber(RETRY_FREQUENCY, frequency);
        flush();
    }
    isDialogAlreadyShown() {
        return this.dialogLastTimeShown !== -1;
    }
    canShowAutoStartDialog() {
        const showWindowOpened = (this.dialogLastTimeShown + this.retryFrequency) < Date.now();
        return showWindowOpened && !this.screenAlreadyShown && this.showAgain;
    }
    clearAutoStarterState() {
        this._screenAlreadyShown = false;
        this._dialogLastTimeShown = -1;
        this._showAgain = true;
        remove(SCREEN_ALREADY_SHOWN);
        remove(DIALOG_LAST_TIME_SHOWN);
        remove(SHOW_AGAIN);
        flush();
    }
    getNumber(key) {
        const stringValue = getString(key, "-1");
        return parseInt(stringValue);
    }
    setNumber(key, value) {
        setString(key, value.toString());
        flush();
    }
}
let _instance;
export function getAutoStarterState() {
    if (!_instance) {
        _instance = new AutoStarterState();
    }
    return _instance;
}
//# sourceMappingURL=state.js.map