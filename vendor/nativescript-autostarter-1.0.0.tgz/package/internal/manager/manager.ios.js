export class IOSAutoStarterManager {
    canShowAutoStartDialogRequest() {
        return false;
    }
    showAutoStartDialogRequest() {
        return Promise.resolve(undefined);
    }
    restartAutoStarterState() {
    }
}
//# sourceMappingURL=manager.ios.js.map