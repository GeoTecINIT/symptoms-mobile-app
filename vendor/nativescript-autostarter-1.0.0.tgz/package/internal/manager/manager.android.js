import { AutoStarterDialog, AutoStarterDialogResponse } from "../dialog";
export class AndroidAutoStarterManager {
    constructor(helper, state) {
        this.helper = helper;
        this.state = state;
        this.dialog = new AutoStarterDialog();
    }
    canShowAutoStartDialogRequest() {
        return this.helper.isAutoStarterPermissionAvailable() && this.state.canShowAutoStartDialog();
    }
    showAutoStartDialogRequest() {
        return this.dialog.show(this.state.isDialogAlreadyShown())
            .then(result => this.handleAutoStartDialogResult(result));
    }
    restartAutoStarterState() {
        this.state.clearAutoStarterState();
    }
    handleAutoStartDialogResult(wantsTo) {
        this.state.dialogLastTimeShown = Date.now();
        if (wantsTo === undefined) {
            this.state.showAgain = false;
            return AutoStarterDialogResponse.DONT_SHOW_AGAIN;
        }
        if (!wantsTo) {
            return AutoStarterDialogResponse.CANCELLED;
        }
        this.state.screenAlreadyShown = true;
        this.helper.launchAutoStartPermissionScreen();
        return AutoStarterDialogResponse.OK;
    }
}
//# sourceMappingURL=manager.android.js.map