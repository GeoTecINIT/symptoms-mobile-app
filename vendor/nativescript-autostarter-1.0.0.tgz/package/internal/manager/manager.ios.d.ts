import { AutoStarterManager } from "./index";
import { AutoStarterDialogResponse } from "../dialog";
export declare class IOSAutoStarterManager implements AutoStarterManager {
    canShowAutoStartDialogRequest(): boolean;
    showAutoStartDialogRequest(): Promise<AutoStarterDialogResponse>;
    restartAutoStarterState(): void;
}
