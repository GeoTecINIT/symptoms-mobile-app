import { AutoStarterDialogResponse } from "../dialog";
import { AutoStarterHelper } from "../helper.android";
import { AutoStarterState } from "../state";
import { AutoStarterManager } from "./index";
export declare class AndroidAutoStarterManager implements AutoStarterManager {
    private helper;
    private state;
    private dialog;
    constructor(helper: AutoStarterHelper, state: AutoStarterState);
    canShowAutoStartDialogRequest(): boolean;
    showAutoStartDialogRequest(): Promise<AutoStarterDialogResponse>;
    restartAutoStarterState(): void;
    private handleAutoStartDialogResult;
}
