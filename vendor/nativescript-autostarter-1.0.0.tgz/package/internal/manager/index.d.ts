import { AutoStarterDialogResponse } from "../dialog";
export declare function getAutoStarterManager(): AutoStarterManager;
export interface AutoStarterManager {
    canShowAutoStartDialogRequest(): boolean;
    showAutoStartDialogRequest(): Promise<AutoStarterDialogResponse>;
    restartAutoStarterState(): void;
}
