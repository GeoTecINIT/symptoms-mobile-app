import { Application } from "@nativescript/core";
import { AndroidAutoStarterManager } from "./manager.android";
import { AutoStarterHelper } from "../helper.android";
import { getAutoStarterState } from "../state";
import { IOSAutoStarterManager } from "./manager.ios";
export function getAutoStarterManager() {
    if (Application.android) {
        return new AndroidAutoStarterManager(new AutoStarterHelper(), getAutoStarterState());
    }
    else {
        return new IOSAutoStarterManager();
    }
}
//# sourceMappingURL=index.js.map