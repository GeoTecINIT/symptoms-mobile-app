export function toMilliseconds(retryFrequency) {
    return retryFrequency.value * millisecondsInUnit(retryFrequency.unit);
}
function millisecondsInUnit(unit) {
    switch (unit) {
        case "minutes":
            return 60000;
        case "hours":
            return 60000 * 60;
        case "days":
            return 60000 * 60 * 24;
    }
}
//# sourceMappingURL=retry-frequency.js.map