export declare class AutoStarterDialog {
    constructor();
    show(alreadyShown: boolean): Promise<boolean>;
    private getString;
}
export declare enum AutoStarterDialogResponse {
    OK = "OK",
    CANCELLED = "CANCELLED",
    DONT_SHOW_AGAIN = "DONT_SHOW_AGAIN"
}
