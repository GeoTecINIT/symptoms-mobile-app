import { Application, Utils } from "@nativescript/core";
export function fetchString(key) {
    if (Application.android) {
        try {
            const id = Utils.android.resources.getStringId(key);
            return Application.android.context.getResources().getString(id);
        }
        catch (e) {
            return undefined;
        }
    }
    else {
        return undefined;
    }
}
//# sourceMappingURL=string-fetcher.js.map