import { Dialogs } from "@nativescript/core";
import { fetchString } from "./string-fetcher";
const DIALOG_STRINGS_KEYS = {
    title: "autostarter_dialog_title",
    message: "autostarter_dialog_message",
    okButtonText: "autostarter_dialog_okButtonText",
    cancelButtonText: "autostarter_dialog_cancelButtonText",
    dontShowAgainButtonText: "autostarter_dialog_dontShowAgainButtonText"
};
const DEFAULT_OPTIONS = {
    title: "Autostart permissions",
    message: "The app could not work as expected if you don't grant the autostart permissions. " +
        "Tap OK to go to the autostart screen options and to grant the required permissions to this app.",
    okButtonText: "OK",
    cancelButtonText: "Cancelllll",
    dontShowAgainButtonText: "Don't show again"
};
export class AutoStarterDialog {
    constructor() {
    }
    show(alreadyShown) {
        return Dialogs.confirm({
            title: this.getString("title"),
            message: this.getString("message"),
            okButtonText: this.getString("okButtonText"),
            cancelButtonText: this.getString("cancelButtonText"),
            neutralButtonText: alreadyShown ? this.getString("neutralButtonText") : undefined,
            cancelable: false,
        });
    }
    getString(key) {
        var _a;
        return (_a = fetchString(DIALOG_STRINGS_KEYS[key])) !== null && _a !== void 0 ? _a : DEFAULT_OPTIONS[key];
    }
}
export var AutoStarterDialogResponse;
(function (AutoStarterDialogResponse) {
    AutoStarterDialogResponse["OK"] = "OK";
    AutoStarterDialogResponse["CANCELLED"] = "CANCELLED";
    AutoStarterDialogResponse["DONT_SHOW_AGAIN"] = "DONT_SHOW_AGAIN";
})(AutoStarterDialogResponse || (AutoStarterDialogResponse = {}));
//# sourceMappingURL=index.js.map