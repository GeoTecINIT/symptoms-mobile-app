export declare function fetchString(key: string): string;
