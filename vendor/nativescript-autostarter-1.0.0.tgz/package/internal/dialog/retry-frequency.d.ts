export interface RetryFrequency {
    value: number;
    unit: FrequencyUnit;
}
type FrequencyUnit = "minutes" | "hours" | "days";
export declare function toMilliseconds(retryFrequency: RetryFrequency): number;
export {};
