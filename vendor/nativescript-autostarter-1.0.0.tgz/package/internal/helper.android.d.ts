export declare class AutoStarterHelper {
    private helper;
    constructor(helper?: any);
    isAutoStarterPermissionAvailable(): any;
    launchAutoStartPermissionScreen(): any;
}
