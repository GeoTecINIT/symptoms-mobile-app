export declare class AutoStarterState {
    private _screenAlreadyShown;
    private _dialogLastTimeShown;
    private _showAgain;
    private _retryFrequency;
    get screenAlreadyShown(): boolean;
    set screenAlreadyShown(shown: boolean);
    get dialogLastTimeShown(): number;
    set dialogLastTimeShown(timestamp: number);
    get showAgain(): boolean;
    set showAgain(show: boolean);
    get retryFrequency(): number;
    set retryFrequency(frequency: number);
    isDialogAlreadyShown(): boolean;
    canShowAutoStartDialog(): boolean;
    clearAutoStarterState(): void;
    private getNumber;
    private setNumber;
}
export declare function getAutoStarterState(): AutoStarterState;
