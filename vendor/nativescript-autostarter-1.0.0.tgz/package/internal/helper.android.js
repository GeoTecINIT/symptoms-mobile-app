import { Application } from "@nativescript/core";
var AutoStarter = com.judemanutd.autostarter.AutoStartPermissionHelper;
export class AutoStarterHelper {
    constructor(helper = AutoStarter.Companion.getInstance()) {
        this.helper = helper;
    }
    isAutoStarterPermissionAvailable() {
        const onlyIfSupported = true;
        return this.helper.isAutoStartPermissionAvailable(Application.android.context, onlyIfSupported);
    }
    launchAutoStartPermissionScreen() {
        const openScreen = true;
        const openInNewTask = true;
        return this.helper.getAutoStartPermission(Application.android.context, openScreen, openInNewTask);
    }
}
//# sourceMappingURL=helper.android.js.map