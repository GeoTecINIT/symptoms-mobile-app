/// <reference path="android-declarations.d.ts"/>

declare module com {
	export module judemanutd {
		export module autostarter {
			export class AutoStartPermissionHelper {
				public static class: java.lang.Class<com.judemanutd.autostarter.AutoStartPermissionHelper>;
				public static Companion: com.judemanutd.autostarter.AutoStartPermissionHelper.Companion;
				public static getInstance(): com.judemanutd.autostarter.AutoStartPermissionHelper;
				public getAutoStartPermission(param0: globalAndroid.content.Context, param1: boolean, param2: boolean): boolean;
				public isAutoStartPermissionAvailable(param0: globalAndroid.content.Context, param1: boolean): boolean;
			}
			export module AutoStartPermissionHelper {
				export class Comp {
					public static class: java.lang.Class<com.judemanutd.autostarter.AutoStartPermissionHelper.Companion>;
					public getInstance(): com.judemanutd.autostarter.AutoStartPermissionHelper;
				}
			}
		}
	}
}

declare module com {
	export module judemanutd {
		export module autostarter {
			export class BuildConfig {
				public static class: java.lang.Class<com.judemanutd.autostarter.BuildConfig>;
				public static DEBUG: boolean;
				public static LIBRARY_PACKAGE_NAME: string;
				public static BUILD_TYPE: string;
				public static VERSION_CODE: number;
				public static VERSION_NAME: string;
				public constructor();
			}
		}
	}
}
