import { Observable } from '@nativescript/core';
import { RetryFrequency } from "./internal/dialog/retry-frequency";
import { AutoStarterManager } from "./internal/manager";
export declare class Common extends Observable {
    init(configParams?: ConfigParams): void;
    getManager(): AutoStarterManager;
}
export interface ConfigParams {
    retryFrequency?: RetryFrequency;
}
