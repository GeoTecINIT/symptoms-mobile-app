import { Common } from './autostarter.common';
export declare class Autostarter extends Common {
  // define your typings manually
  // or..
  // take the ios or android .d.ts files and copy/paste them here
}

export declare const autoStarter = new Autostarter();
export { ConfigParams } from "./autostarter.common";
