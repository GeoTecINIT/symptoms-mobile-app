import { Common } from './autostarter.common';
export class Autostarter extends Common {
}
//# sourceMappingURL=autostarter.ios.js.map