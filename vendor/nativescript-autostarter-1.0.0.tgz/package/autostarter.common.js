import { Observable } from '@nativescript/core';
import { toMilliseconds } from "./internal/dialog/retry-frequency";
import { getAutoStarterState } from "./internal/state";
import { getAutoStarterManager } from "./internal/manager";
export class Common extends Observable {
    init(configParams) {
        if (!configParams) {
            return;
        }
        if (configParams.retryFrequency) {
            getAutoStarterState().retryFrequency = toMilliseconds(configParams.retryFrequency);
        }
    }
    getManager() {
        return getAutoStarterManager();
    }
}
//# sourceMappingURL=autostarter.common.js.map