import { Common } from './autostarter.common';
export declare class Autostarter extends Common {
}
export declare const autoStarter: Autostarter;
